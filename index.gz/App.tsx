import { useEffect, useState, useRef, useMemo } from 'react';
import logoUrl from "container:///mnt/data/src/assets/739202fb338e864d-Protezione_Civile_Logo";

type Role = 'volontario' | 'coordinatore' | 'servizio';
type Volunteer = { name: string; pin: string; role: Role; active: boolean; };
type EventType = 'timbratura' | 'fine_servizio' | 'emergenza' | 'posizione';
type EventRec = { type: EventType; volunteerId: string; volunteerName: string; lat?: number; lng?: number; distance?: number; ts: number; note?: string; groupCode?: string };
type ChatRec = { volunteerId: string; volunteerName: string; message: string; ts: number; groupCode?: string };
type RequestRec = { type: 'ferie' | 'reperibilita'; volunteerId: string; volunteerName: string; from: string; to: string; status: 'in_attesa'|'approvata'|'rifiutata'; ts: number; groupCode?: string };
type SettingsRec = { groupCode: string; motto: string; npointId?: string; firebase?: { apiKey: string; projectId: string }; };
type PosLog = { ts:number; lat:number; lng:number; volunteerName:string; };

const SEDE = { lat: 44.897036, lng: 8.597517 };
const RAGGIO = 150;
const EMERGENCY_COOLDOWN = 30 * 60 * 1000;
const POSITION_INTERVAL = 30 * 60 * 1000; // 30 minuti reali = 1800000 ms FIX DEFINITIVO
const MOTTO = "Ovunque, per tutti - Presenti quando conta.";

function haversine(lat1:number, lon1:number, lat2:number, lon2:number){
  const R=6371000;
  const dLat=(lat2-lat1)*Math.PI/180;
  const dLon=(lon2-lon1)*Math.PI/180;
  const a=Math.sin(dLat/2)**2 + Math.cos(lat1*Math.PI/180)*Math.cos(lat2*Math.PI/180)*Math.sin(dLon/2)**2;
  return 2*R*Math.asin(Math.sqrt(a));
}
function fmtTime(ts:number){ return new Date(ts).toLocaleString('it-IT',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}); }
function fmtDate(ts:number){ return new Date(ts).toLocaleDateString('it-IT',{weekday:'short', day:'2-digit', month:'short'}); }
function fmtCountdown(ms:number){
  if(ms<=0) return "invio in corso...";
  const totalSec = Math.floor(ms/1000);
  const m = Math.floor(totalSec/60);
  const s = totalSec%60;
  return `${m}m ${s.toString().padStart(2,'0')}s`;
}
async function api(action:string, args:any){
  const res = await fetch("actions", { method:"POST", headers:{ "content-type":"application/json" }, body: JSON.stringify({ action, args }) });
  const j = await res.json();
  if(!res.ok || j.error) throw new Error(j.error || `HTTP ${res.status}`);
  return j.data;
}

export default function App(){
  const [volunteers, setVolunteers] = useState<{id:string, value:Volunteer}[]>([]);
  const [events, setEvents] = useState<{id:string,value:EventRec}[]>([]);
  const [chats, setChats] = useState<{id:string,value:ChatRec}[]>([]);
  const [requests, setRequests] = useState<{id:string,value:RequestRec}[]>([]);
  const [settings, setSettings] = useState<{id:string,value:SettingsRec}|null>(null);

  const [syncState, setSyncState] = useState<'sync'|'offline'|'npoint'|'error'>('offline');
  const [syncModeLabel, setSyncModeLabel] = useState('Verifica connessione...');
  const [lastSync, setLastSync] = useState<number|null>(null);
  const [busy, setBusy] = useState(false);
  const [currentUser, setCurrentUser] = useState<{id:string,value:Volunteer}|null>(null);
  const [loginSelect, setLoginSelect] = useState('');
  const [pinInput, setPinInput] = useState('');
  const [loginError, setLoginError] = useState('');
  const [tab, setTab] = useState<'home'|'timbra'|'emergenza'|'chat'|'schede'>('home');
  const [month, setMonth] = useState(new Date().getMonth());
  const [year, setYear] = useState(new Date().getFullYear());
  const [chatMsg, setChatMsg] = useState('');
  const [ferieFrom, setFerieFrom] = useState('');
  const [ferieTo, setFerieTo] = useState('');
  const [ferieTipo, setFerieTipo] = useState<'ferie'|'reperibilita'>('ferie');
  const [groupInput, setGroupInput] = useState('PC-AL-2024');
  const [npointInput, setNpointInput] = useState('');
  const [showSettings, setShowSettings] = useState(false);
  const [fbApi, setFbApi] = useState('');
  const [fbProject, setFbProject] = useState('');
  const [editingVol, setEditingVol] = useState<{id:string, value:Volunteer}|null>(null);
  const [newVol, setNewVol] = useState<Volunteer>({ name:'', pin:'', role:'volontario', active:true });
  const [geo, setGeo] = useState<{lat:number,lng:number,acc:number}|null>(null);
  const [geoErr, setGeoErr] = useState('');
  const [statusMsg, setStatusMsg] = useState('');
  const [showPinPad, setShowPinPad] = useState(false);

  const [lastPosSend, setLastPosSend] = useState<number>(()=> Date.now() - POSITION_INTERVAL + 2*60*1000);
  const [posCountdown, setPosCountdown] = useState<string>('30m 00s');
  const [posLogs, setPosLogs] = useState<PosLog[]>([]);
  const [posEnabled, setPosEnabled] = useState(true);

  const bcRef = useRef<BroadcastChannel|null>(null);

  const groupCode = settings?.value.groupCode || 'PC-AL-2024';
  const npointId = settings?.value.npointId || npointInput || '';

  const filteredEvents = useMemo(()=> events.filter(e=> !e.value.groupCode || e.value.groupCode===groupCode), [events,groupCode]);
  const filteredChats = useMemo(()=> chats.filter(c=> !c.value.groupCode || c.value.groupCode===groupCode), [chats,groupCode]);
  const filteredRequests = useMemo(()=> requests.filter(r=> !r.value.groupCode || r.value.groupCode===groupCode), [requests,groupCode]);

  async function reload(){
    try{
      const [v,e,c,r,s] = await Promise.all([
        api('records.list',{collection:'volunteers'}),
        api('records.list',{collection:'events'}),
        api('records.list',{collection:'chats'}),
        api('records.list',{collection:'requests'}),
        api('records.list',{collection:'settings'}),
      ]);
      setVolunteers(v.records);
      setEvents(e.records.sort((a:any,b:any)=>b.value.ts-a.value.ts));
      setChats(c.records.sort((a:any,b:any)=>a.value.ts-b.value.ts));
      setRequests(r.records.sort((a:any,b:any)=>b.value.ts-a.value.ts));
      if(s.records[0]){
        setSettings(s.records[0]);
        setGroupInput(s.records[0].value.groupCode);
        setNpointInput(s.records[0].value.npointId||'');
        setFbApi(s.records[0].value.firebase?.apiKey||'');
        setFbProject(s.records[0].value.firebase?.projectId||'');
      } else {
        const def:SettingsRec={groupCode:'PC-AL-2024', motto:MOTTO};
        const created = await api('records.create',{collection:'settings', value:def});
        setSettings(created);
      }
      setSyncState('sync');
      setSyncModeLabel('Modalità Cloud — sincronizzata (deployment con backend)');
      setLastSync(Date.now());
      if(v.records.length===0){
        const seeds:Volunteer[]=[
          { name:'Coordinatore Rossi', pin:'1234', role:'coordinatore', active:true },
          { name:'Servizio Centrale', pin:'0000', role:'servizio', active:true },
          { name:'Bianchi Marco', pin:'1111', role:'volontario', active:true },
          { name:'Ferrari Anna', pin:'2222', role:'volontario', active:true },
          { name:'Esposito Luca', pin:'3333', role:'volontario', active:true },
        ];
        for(const s of seeds){ await api('records.create',{collection:'volunteers', value:s}); }
        const rev = await api('records.list',{collection:'volunteers'});
        setVolunteers(rev.records);
      }
    }catch(err){
      // GitHub Pages statico: niente backend, resto in locale ma mostro istruzioni
      setSyncState('offline');
      if(npointId){
        setSyncModeLabel(`Modalità GitHub Pages — locale + npoint ID salvato (${npointId.slice(0,8)}...). Per sync reale usa link deployment.`);
      } else {
        setSyncModeLabel('Modalità GitHub Pages — solo locale. Per sync cloud apri il link del deployment con backend o imposta npoint in Impostazioni.');
      }
      // se già abbiamo volontari in memoria, non azzerare
      if(volunteers.length===0){
        // mock locale per demo GH Pages
        const localSeeds:Volunteer[]=[
          { name:'Coordinatore Rossi', pin:'1234', role:'coordinatore', active:true },
          { name:'Servizio Centrale', pin:'0000', role:'servizio', active:true },
          { name:'Bianchi Marco', pin:'1111', role:'volontario', active:true },
        ];
        setVolunteers(localSeeds.map((v,i)=>({id:`local-${i}`, value:v})));
      }
    }
  }

  useEffect(()=>{
    reload();
    const id = window.setInterval(reload, 15000);
    try{
      bcRef.current = new BroadcastChannel('pc-al-sync');
      bcRef.current.onmessage = (ev)=>{ if(ev.data==='reload') reload(); };
    }catch{}
    return ()=>{ clearInterval(id); bcRef.current?.close(); };
  },[]);

  useEffect(()=>{
    if(!navigator.geolocation) { setGeoErr('GPS non disponibile'); return; }
    const watch = navigator.geolocation.watchPosition((p)=>{
      setGeo({lat:p.coords.latitude,lng:p.coords.longitude,acc:p.coords.accuracy});
      setGeoErr('');
    }, (e)=> setGeoErr(e.message), {enableHighAccuracy:true});
    return ()=> navigator.geolocation.clearWatch(watch);
  },[]);

  useEffect(()=>{
    const tick = window.setInterval(()=>{
      const elapsed = Date.now() - lastPosSend;
      const remaining = POSITION_INTERVAL - elapsed;
      setPosCountdown(fmtCountdown(remaining));
      if(posEnabled && currentUser && geo && remaining<=0){
        const log:PosLog = { ts: Date.now(), lat: geo.lat, lng: geo.lng, volunteerName: currentUser.value.name };
        setPosLogs(l=>[log, ...l].slice(0,30));
        setLastPosSend(Date.now());
        (async ()=>{
          try{
            const rec:EventRec={ type:'posizione', volunteerId:currentUser.id, volunteerName:currentUser.value.name, lat:geo.lat, lng:geo.lng, distance: distance||undefined, ts:Date.now(), note:`Auto ogni 30min reali`, groupCode };
            if(syncState==='sync'){
              await api('records.create',{collection:'events', value:rec});
            }
            setEvents(prev=> [{id:`pos-${Date.now()}`, value:rec}, ...prev]);
            setStatusMsg(`📍 Posizione inviata alle ${new Date().toLocaleTimeString('it-IT')} — prossimo tra 30 min`);
            setTimeout(()=>setStatusMsg(''), 4000);
          }catch{}
        })();
      }
    }, 1000);
    return ()=> clearInterval(tick);
  },[lastPosSend, posEnabled, currentUser, geo, syncState, groupCode]);

  const distance = geo ? haversine(geo.lat, geo.lng, SEDE.lat, SEDE.lng) : null;
  const inRange = distance!==null && distance<=RAGGIO;

  const lastEmergency = useMemo(()=>{
    if(!currentUser) return null;
    const ev = filteredEvents.find(e=> e.value.type==='emergenza' && e.value.volunteerId===currentUser.id);
    return ev?.value.ts || null;
  },[filteredEvents,currentUser]);

  const canEmergency = !lastEmergency || (Date.now() - lastEmergency) > EMERGENCY_COOLDOWN;

  async function handleLogin(){
    setLoginError('');
    const vol = volunteers.find(v=> v.id===loginSelect);
    if(!vol){ setLoginError('Seleziona un nominativo'); return; }
    if(vol.value.pin !== pinInput){ setLoginError('PIN errato'); return; }
    if(!vol.value.active){ setLoginError('Utente disattivato'); return; }
    setCurrentUser(vol);
    setTab('home');
    setShowPinPad(false);
    setLastPosSend(Date.now());
  }

  async function doEvent(type:EventType, note?:string){
    if(!currentUser) return;
    if(type==='emergenza' && !canEmergency){ setStatusMsg('Attendi 30 min tra emergenze'); return; }
    setBusy(true);
    try{
      const rec:EventRec={ type, volunteerId:currentUser.id, volunteerName:currentUser.value.name, lat:geo?.lat, lng:geo?.lng, distance: distance||undefined, ts:Date.now(), note, groupCode };
      if(syncState==='sync'){
        await api('records.create',{collection:'events', value:rec, idempotency_key: `${type}-${currentUser.id}-${Date.now()}`});
      }
      setEvents(prev=> [{id:`local-${Date.now()}`, value:rec}, ...prev]);
      if(type==='posizione'){
        setPosLogs(l=> [{ts:rec.ts, lat:rec.lat||0, lng:rec.lng||0, volunteerName:rec.volunteerName}, ...l].slice(0,30));
        setLastPosSend(Date.now());
      }
      setStatusMsg(type==='emergenza' ? '🚨 Emergenza segnalata!' : type==='timbratura' ? '✅ Timbratura registrata' : type==='posizione' ? '📍 Posizione inviata — prossimo tra 30 min' : '🏁 Fine servizio');
      bcRef.current?.postMessage('reload');
      if(syncState==='sync') await reload();
      setTimeout(()=>setStatusMsg(''),3000);
    }catch(e:any){ setStatusMsg('Errore: '+e.message); }
    setBusy(false);
  }

  async function sendChat(){
    if(!chatMsg.trim()||!currentUser) return;
    try{
      const rec:ChatRec={ volunteerId:currentUser.id, volunteerName:currentUser.value.name, message:chatMsg.trim(), ts:Date.now(), groupCode };
      if(syncState==='sync'){
        await api('records.create',{collection:'chats', value:rec});
      }
      setChats(prev=> [...prev, {id:`chat-${Date.now()}`, value:rec}]);
      setChatMsg('');
      bcRef.current?.postMessage('reload');
      if(syncState==='sync') await reload();
    }catch{}
  }

  async function sendRequest(){
    if(!ferieFrom||!ferieTo||!currentUser) return;
    try{
      const rec:RequestRec={ type:ferieTipo, volunteerId:currentUser.id, volunteerName:currentUser.value.name, from:ferieFrom, to:ferieTo, status:'in_attesa', ts:Date.now(), groupCode };
      if(syncState==='sync'){
        await api('records.create',{collection:'requests', value:rec});
      }
      setRequests(prev=> [{id:`req-${Date.now()}`, value:rec}, ...prev]);
      setFerieFrom(''); setFerieTo('');
      setStatusMsg('Richiesta inviata');
      if(syncState==='sync') await reload();
    }catch(e:any){ setStatusMsg(e.message); }
  }

  async function saveSettings(){
    try{
      const val:SettingsRec={ groupCode:groupInput.trim()||'PC-AL-2024', motto: MOTTO, npointId: npointInput.trim()||undefined, firebase: fbApi ? {apiKey:fbApi, projectId:fbProject} : undefined };
      if(settings && !settings.id.startsWith('local') && !settings.id.startsWith('np-')){
        await api('records.replace',{collection:'settings', id:settings.id, value:val});
        setSettings({...settings, value:val});
      } else if(syncState==='sync'){
        const created = await api('records.create',{collection:'settings', value:val});
        setSettings(created);
      } else {
        setSettings({id:'local', value:val});
      }
      setStatusMsg('Impostazioni salvate');
      await reload();
      setShowSettings(false);
    }catch(e:any){
      const val:SettingsRec={ groupCode:groupInput.trim()||'PC-AL-2024', motto: MOTTO, npointId: npointInput.trim()||undefined, firebase: fbApi ? {apiKey:fbApi, projectId:fbProject} : undefined };
      setSettings({id:'local', value:val});
      setStatusMsg('Salvato locale (modalità GitHub Pages)');
      setShowSettings(false);
    }
  }

  async function upsertVolunteer(){
    try{
      if(editingVol){
        if(syncState==='sync' && !editingVol.id.startsWith('local')){
          await api('records.replace',{collection:'volunteers', id:editingVol.id, value:editingVol.value});
        } else {
          setVolunteers(v=> v.map(x=> x.id===editingVol.id ? editingVol : x));
        }
        setEditingVol(null);
      }else{
        if(!newVol.name||!newVol.pin) { setStatusMsg('Nome e PIN obbligatori'); return; }
        if(syncState==='sync'){
          await api('records.create',{collection:'volunteers', value:newVol});
          await reload();
        } else {
          setVolunteers(prev=> [...prev, {id:`vol-${Date.now()}`, value:newVol}]);
        }
        setNewVol({name:'',pin:'',role:'volontario',active:true});
      }
      if(syncState==='sync') await reload();
    }catch(e:any){ setStatusMsg(e.message); }
  }

  async function deleteVolunteer(id:string){
    if(!confirm('Eliminare volontario?')) return;
    try{
      if(syncState==='sync' && !id.startsWith('local') && !id.startsWith('vol-')){
        await api('records.delete',{collection:'volunteers', id});
      }
      setVolunteers(v=> v.filter(x=>x.id!==id));
      if(syncState==='sync') await reload();
    }catch(e:any){ setStatusMsg(e.message); }
  }

  async function approveRequest(id:string, status:RequestRec['status']){
    const r = requests.find(x=>x.id===id) || filteredRequests.find(x=>x.id===id);
    if(!r) return;
    try{
      if(syncState==='sync' && !id.startsWith('local') && !id.startsWith('np-')){
        await api('records.replace',{collection:'requests', id, value:{...r.value, status}});
      }
      setRequests(prev=> prev.map(x=> x.id===id ? {...x, value:{...x.value, status}} : x));
      if(syncState==='sync') await reload();
    }catch{}
  }

  const pressDigit = (d:string)=>{ if(pinInput.length>=4) return; setPinInput(p=> (p+d).slice(0,4)); };
  const pressBack = ()=> setPinInput(p=> p.slice(0,-1));
  const pressClear = ()=> setPinInput('');

  const monthEvents = filteredEvents.filter(ev=>{
    const d=new Date(ev.value.ts);
    return d.getMonth()===month && d.getFullYear()===year;
  });

  const emergencyCountdown = useMemo(()=>{
    if(!lastEmergency) return null;
    const remaining = EMERGENCY_COOLDOWN - (Date.now() - lastEmergency);
    if(remaining<=0) return null;
    return fmtCountdown(remaining);
  },[lastEmergency, posCountdown]);

  return (
    <div data-safe-area-inset-root className="min-h-[100dvh] w-full bg-[var(--bg)] text-[var(--text)] overflow-x-clip" style={{boxSizing:'border-box', paddingTop:'var(--safe-area-inset-top)'}}>
      <style>{`
        .glass { backdrop-filter: blur(18px); -webkit-backdrop-filter: blur(18px); }
        .btn-giant { min-height: 88px; font-size: 1.35rem; letter-spacing:.02em; }
        .shadow-soft { box-shadow: 0 8px 30px rgba(12,45,94,.08); }
        .pin-input-fix{
          color-scheme: light !important;
          background-color: #ffffff !important;
          background: #ffffff !important;
          color: #000000 !important;
          -webkit-text-fill-color: #000000 !important;
          caret-color: #000000 !important;
          border: 3px solid #ffcc00 !important;
          font-size: 24px !important;
          font-weight: 800 !important;
          height: 60px !important;
          letter-spacing: 0.45em !important;
          text-align: center;
        }
        .pin-input-fix::placeholder{
          color: #555555 !important;
          -webkit-text-fill-color: #555555 !important;
          opacity: 1 !important;
          letter-spacing: normal !important;
          font-size: 16px !important;
          font-weight: 600 !important;
        }
        .pin-input-fix:focus{
          background-color: #ffffff !important;
          color: #000000 !important;
          border-color: #ffcc00 !important;
          box-shadow: 0 0 0 4px rgba(255,204,0,0.35), 0 6px 20px rgba(0,0,0,0.12) !important;
          outline: none !important;
        }
        .key-yellow{
          background: #ffcc00 !important;
          color: #0f2c5c !important;
          border: 2px solid #e6b800 !important;
          box-shadow: 0 4px 0 #c49c00, 0 8px 18px rgba(0,0,0,0.18) !important;
          height: 64px !important;
          min-height: 64px !important;
        }
        .key-yellow:active{ transform: translateY(2px); box-shadow: 0 2px 0 #c49c00, 0 4px 10px rgba(0,0,0,0.18) !important; }
        .key-blue{
          background: #0f2c5c !important;
          color: #ffffff !important;
          border: 2px solid #0a1e40 !important;
          box-shadow: 0 4px 0 #07132a, 0 8px 18px rgba(0,0,0,0.25) !important;
          height: 64px !important;
          min-height: 64px !important;
        }
        .key-white{
          background: #ffffff !important;
          color: #0f2c5c !important;
          border: 3px solid #ffcc00 !important;
          box-shadow: 0 4px 0 #ffcc00, 0 8px 18px rgba(0,0,0,0.12) !important;
          height: 64px !important;
          min-height: 64px !important;
        }
      `}</style>

      <header data-safe-area-sticky-top className="sticky z-30 bg-[var(--surface)]/90 glass border-b border-[var(--line)]" style={{top:'var(--safe-area-inset-top)'}}>
        <div className="mx-auto max-w-[1080px] px-4 h-[64px] flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <img src={logoUrl} alt="Protezione Civile" className="h-[42px] w-[42px] object-contain rounded-full bg-white p-1 shadow-soft"/>
            <div className="leading-none">
              <div className="cond font-bold text-[18px] text-[var(--pc-blue)] tracking-wide">P.C. ALESSANDRIA</div>
              <div className="text-[10px] font-semibold text-[var(--text-muted)] uppercase tracking-[0.18em]">{MOTTO}</div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className={`flex items-center gap-1.5 rounded-full border px-3 py-1.5 ${syncState==='sync'?'bg-emerald-50 border-emerald-200': syncState==='npoint'?'bg-blue-50 border-blue-200': syncState==='offline'?'bg-amber-50 border-amber-200':'bg-red-50 border-red-200'}`}>
              <span className={`h-2.5 w-2.5 rounded-full ${syncState==='sync' ? 'bg-emerald-500 animate-pulse' : syncState==='npoint' ? 'bg-blue-500 animate-pulse' : syncState==='offline' ? 'bg-amber-400' : 'bg-red-500'}`}/>
              <span className="text-[11px] font-semibold uppercase tracking-wide">
                {syncState==='sync' ? `Cloud ${lastSync? new Date(lastSync).toLocaleTimeString('it-IT',{hour:'2-digit',minute:'2-digit'}):''}` : syncState==='npoint' ? `npoint` : syncState==='offline' ? 'Locale' : 'Errore'}
              </span>
            </div>
            {currentUser && (
              <button onClick={()=>setShowSettings(!showSettings)} className="h-9 w-9 grid place-items-center rounded-full bg-[var(--pc-blue)] text-white">⚙</button>
            )}
          </div>
        </div>
      </header>

      {statusMsg && (
        <div className="fixed left-1/2 -translate-x-1/2 top-[80px] z-50 rounded-full bg-[var(--text)] text-white px-5 py-2 text-sm shadow-xl">{statusMsg}</div>
      )}

      <main className="mx-auto max-w-[1080px] px-4 pb-[96px] pt-4">
        {!currentUser ? (
          <div className="grid md:grid-cols-[1.1fr_0.9fr] gap-6 mt-2">
            <div className="rounded-[28px] bg-[var(--surface)] border border-[var(--line)] shadow-soft p-6 md:p-8">
              <div className="inline-flex items-center gap-2 rounded-full bg-[var(--pc-yellow)] px-3 py-1 text-[11px] font-bold uppercase tracking-wide text-[var(--pc-blue)]">Accesso Volontari - Alessandria</div>
              <h1 className="cond mt-4 text-[42px] leading-[0.9] font-bold">Accedi al<br/>Servizio</h1>
              <p className="mt-3 text-sm text-[var(--text-muted)]">Motto: <b>{MOTTO}</b> — PIN mai visibili in lista. Tastierino giallo 64px alta visibilità.</p>

              <div className="mt-7 space-y-5">
                <div>
                  <label className="text-[11px] font-bold uppercase tracking-wide text-[var(--text-muted)]">Volontario / Ruolo</label>
                  <select value={loginSelect} onChange={e=>setLoginSelect(e.target.value)} className="mt-1 w-full rounded-[14px] border border-[var(--line)] bg-white px-4 py-3.5 text-[16px] font-medium text-black">
                    <option value="">— Seleziona nominativo —</option>
                    {volunteers.map(v=>(
                      <option key={v.id} value={v.id}>{v.value.name} — {v.value.role}</option>
                    ))}
                  </select>
                  <p className="mt-2 text-[11px] text-[var(--text-muted)]">🔒 Sicurezza: solo nomi in dropdown, PIN inserito a parte.</p>
                </div>

                <div>
                  <label className="text-[11px] font-bold uppercase tracking-wide text-[var(--text-muted)] flex items-center justify-between">
                    <span>PIN personale — tocca per tastierino</span>
                    <span className="text-[10px] bg-[#ffcc00] text-[#0f2c5c] px-2 py-0.5 rounded-full font-black border border-[#0f2c5c]">64px ALTO CONTRASTO</span>
                  </label>
                  <div className="mt-2 relative">
                    <input
                      readOnly
                      inputMode="numeric"
                      pattern="[0-9]*"
                      value={pinInput}
                      onClick={()=>setShowPinPad(true)}
                      onFocus={()=>setShowPinPad(true)}
                      placeholder="TOCCA QUI • 4 CIFRE"
                      className="pin-input-fix w-full rounded-[14px] px-4 py-2 text-[24px]"
                      style={{backgroundColor:'#ffffff', color:'#000000', border:'3px solid #ffcc00', height:'60px'}}
                    />
                    <div className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 rounded-full bg-[#0f2c5c] text-white text-[11px] font-bold px-2 py-1">⌨️</div>
                  </div>
                </div>

                {showPinPad && (
                  <div className="rounded-[22px] border-[3px] border-[#ffcc00] bg-white p-4 shadow-[0_12px_40px_rgba(0,0,0,0.22)]">
                    <div className="flex items-center justify-between mb-3">
                      <div className="text-[12px] font-black uppercase tracking-widest text-[#0f2c5c]">Tastierino PIN — 64px • Visibile al sole ☀️</div>
                      <button onClick={()=>setShowPinPad(false)} className="rounded-full bg-[#0f2c5c] text-white text-[11px] font-bold px-3 py-1">CHIUDI ✕</button>
                    </div>

                    <div className="grid grid-cols-3 gap-3">
                      {[1,2,3,4,5,6,7,8,9].map(n=>(
                        <button
                          key={n}
                          onClick={()=>pressDigit(String(n))}
                          className="key-yellow rounded-[14px] text-[28px] font-black tracking-wide"
                        >{n}</button>
                      ))}
                      <button onClick={pressClear} className="key-white rounded-[14px] text-[13px] font-black uppercase">CANC<br/>TUTTO</button>
                      <button onClick={()=>pressDigit('0')} className="key-yellow rounded-[14px] text-[28px] font-black">0</button>
                      <button onClick={pressBack} className="key-white rounded-[14px] text-[20px] font-black">⌫</button>
                    </div>

                    <div className="mt-3 grid grid-cols-2 gap-3">
                      <button onClick={pressBack} className="key-white rounded-[14px] text-[14px] font-black uppercase">⬅ Cancella</button>
                      <button onClick={()=>{ setShowPinPad(false); }} className="key-blue rounded-[14px] text-[15px] font-black uppercase tracking-wide">OK Conferma ✓</button>
                    </div>

                    <div className="mt-3 flex items-center justify-center gap-2">
                      <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse"/><span className="text-[11px] text-black/70">PIN non visibile in elenco — sicurezza attiva</span>
                    </div>
                  </div>
                )}

                {loginError && <div className="rounded-xl bg-red-50 border-2 border-red-200 text-red-700 px-4 py-2 text-[13px]">{loginError}</div>}

                <button onClick={handleLogin} className="w-full rounded-[14px] bg-[#0f2c5c] text-white py-4 font-bold text-[16px] uppercase tracking-wide border-2 border-[#0a1e40] shadow-soft">Accedi al Servizio</button>

                <div className="rounded-[14px] bg-[#0f2c5c] text-white p-4 text-[12px] border-2 border-[#0a1e40]">
                  <b className="uppercase tracking-wide">Fix definitivo 30 min</b><br/>
                  Posizione automatica ogni <b>30 minuti reali (1800000 ms)</b>, non più 30 secondi.<br/>
                  Countdown visibile: <b>{posCountdown}</b><br/>
                  <span className="opacity-80">{syncModeLabel}</span>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="rounded-[20px] bg-white border border-[var(--line)] p-5 shadow-soft">
                <h3 className="cond font-bold text-[18px] text-[#0f2c5c]">Stato Sincronizzazione</h3>
                <div className="mt-3 space-y-2 text-[12px]">
                  <div className="flex justify-between border-b border-dashed py-1"><span className="text-black/60">Modalità attuale</span><b className="text-black">{syncModeLabel}</b></div>
                  <div className="flex justify-between border-b border-dashed py-1"><span className="text-black/60">Gruppo</span><b className="text-black">{groupCode}</b></div>
                  <div className="flex justify-between border-b border-dashed py-1"><span className="text-black/60">Intervallo posizione</span><b className="text-black">30 minuti reali</b></div>
                  <div className="flex justify-between border-b border-dashed py-1"><span className="text-black/60">Prossimo invio</span><b className="text-black">{posCountdown}</b></div>
                  <div className="flex justify-between py-1"><span className="text-black/60">Ultimo sync</span><b className="text-black">{lastSync? fmtTime(lastSync):'mai'}</b></div>
                </div>
                <div className="mt-4 rounded-xl bg-amber-50 border-2 border-amber-200 p-3 text-[11px] text-black leading-[1.35]">
                  <b>Perché GitHub Pages non sincronizza?</b> GitHub Pages è statico: non ha database. La sync reale funziona solo aprendo l'app dal <b>link del deployment con backend</b> (usa <code>records.list/create</code>). Su GitHub Pages i dati restano locali; puoi salvare un <b>npoint ID</b> come promemoria, ma la sync cross-device richiede backend.
                </div>
              </div>

              <div className="rounded-[20px] bg-white border-2 border-[#ffcc00] p-5 shadow-soft">
                <h3 className="cond font-bold text-[16px] text-[#0f2c5c]">Log Posizioni — timestamp visibili</h3>
                <div className="mt-3 max-h-[180px] overflow-auto space-y-1">
                  {posLogs.length===0 && <div className="text-[11px] text-black/60">Nessun invio ancora. Countdown: {posCountdown}</div>}
                  {posLogs.map((l,i)=>(
                    <div key={i} className="flex justify-between text-[11px] border-b border-dashed py-1"><span>{l.volunteerName}</span><span className="font-mono">{fmtTime(l.ts)} — {l.lat.toFixed(4)},{l.lng.toFixed(4)}</span></div>
                  ))}
                </div>
              </div>

              <div className="rounded-[20px] bg-[#0f2c5c] text-white p-5 border-2 border-[#0a1e40]">
                <div className="text-[12px] uppercase tracking-wide opacity-80">Sede operativa</div>
                <div className="mt-1 text-[14px] font-bold">44.897036, 8.597517 — raggio 150m</div>
                <div className="mt-2 text-[11px] opacity-80">Timbratura normale entro 150m. Emergenza sempre disponibile ovunque.</div>
                {geo && <div className="mt-2 text-[11px] font-mono">GPS: {geo.lat.toFixed(5)}, {geo.lng.toFixed(5)} ±{Math.round(geo.acc)}m {distance!==null?`— ${Math.round(distance)}m da sede`:''}</div>}
                {geoErr && <div className="mt-1 text-[11px] text-amber-300">{geoErr}</div>}
              </div>
            </div>
          </div>
        ) : (
          <>
            {showSettings && (
              <div className="mt-4 rounded-[20px] bg-white border-2 border-[#ffcc00] p-5 shadow-soft">
                <div className="flex items-start justify-between gap-3">
                  <div><h2 className="cond font-bold text-[22px] text-[#0f2c5c]">Impostazioni Sincronizzazione</h2><p className="text-[12px] text-black/70 mt-1">{syncModeLabel}</p></div>
                  <button onClick={()=>setShowSettings(false)} className="rounded-full bg-[#0f2c5c] text-white text-[11px] px-3 py-1 font-bold">CHIUDI</button>
                </div>

                <div className="mt-4 grid md:grid-cols-2 gap-4">
                  <div className="space-y-3">
                    <label className="text-[11px] font-bold uppercase">Codice gruppo</label>
                    <input value={groupInput} onChange={e=>setGroupInput(e.target.value)} className="w-full rounded-xl border-2 border-[#0f2c5c] bg-white px-3 py-2.5 text-[13px] text-black"/>
                    <label className="text-[11px] font-bold uppercase">npoint ID (per promemoria GitHub Pages)</label>
                    <input value={npointInput} onChange={e=>setNpointInput(e.target.value)} placeholder="es. abc123def..." className="w-full rounded-xl border-2 border-[#ffcc00] bg-white px-3 py-2.5 text-[13px] text-black"/>
                    <div className="text-[11px] text-black/70 leading-[1.3]">Su GitHub Pages la sync cross-device non è possibile senza backend. Questo ID viene salvato localmente e nel backend cloud quando disponibile. Per attivare sync su GitHub Pages dovresti creare un bin pubblico su npoint.io manualmente e incollare qui l'ID, ma <b>la sync automatica via npoint è disabilitata in questa build per rispettare il backend sicuro</b>; usa il link deployment per sync reale.</div>
                  </div>
                  <div className="space-y-3">
                    <label className="text-[11px] font-bold uppercase">Firebase API Key (opzionale)</label>
                    <input value={fbApi} onChange={e=>setFbApi(e.target.value)} placeholder="API key" className="w-full rounded-xl border border-[var(--line)] bg-white px-3 py-2.5 text-[13px] text-black"/>
                    <label className="text-[11px] font-bold uppercase">Firebase Project ID</label>
                    <input value={fbProject} onChange={e=>setFbProject(e.target.value)} placeholder="project-id" className="w-full rounded-xl border border-[var(--line)] bg-white px-3 py-2.5 text-[13px] text-black"/>
                    <div className="rounded-xl bg-[#0f2c5c] text-white p-3 text-[11px] border">
                      <b>Istruzioni GitHub Pages:</b><br/>
                      1. Carica l'HTML buildato su gh-pages<br/>
                      2. Apri l'app dal link deployment (con backend) per sincronizzare volontari, timbrature, chat<br/>
                      3. Su GitHub Pages, imposta codice gruppo = stesso del deployment<br/>
                      4. Posizione ogni 30 min reali già fixata — countdown visibile sopra
                    </div>
                  </div>
                </div>

                <div className="mt-4 flex flex-wrap gap-2">
                  <button onClick={saveSettings} className="rounded-xl bg-[#0f2c5c] text-white px-5 py-2.5 text-[12px] font-bold uppercase border-2 border-[#0a1e40]">Salva impostazioni</button>
                  <button onClick={()=>{ setCurrentUser(null); setShowSettings(false); }} className="rounded-xl bg-white border-2 border-[#ffcc00] px-5 py-2.5 text-[12px] font-bold uppercase text-black">Logout</button>
                  <div className="ml-auto flex items-center gap-2 text-[11px]">
                    <span className="text-black/60">Sync stato:</span><b className={`px-2 py-1 rounded-full border ${syncState==='sync'?'bg-emerald-50 border-emerald-300 text-emerald-800':'bg-amber-50 border-amber-300 text-amber-800'}`}>{syncModeLabel}</b>
                  </div>
                </div>
              </div>
            )}

            <div className="mt-4 flex flex-wrap items-center gap-2 rounded-[16px] bg-white border border-[var(--line)] px-4 py-3 shadow-soft">
              <div className="text-[13px]"><b>{currentUser.value.name}</b> — {currentUser.value.role} • Gruppo <b>{groupCode}</b></div>
              <div className="ml-auto flex items-center gap-2">
                <span className="text-[11px] text-black/60">Posizione ogni 30 min:</span>
                <span className="text-[11px] px-2 py-1 rounded-full bg-[#0f2c5c] text-white font-bold">Prossimo invio tra: {posCountdown}</span>
                <label className="flex items-center gap-1 text-[11px]"><input type="checkbox" checked={posEnabled} onChange={e=>setPosEnabled(e.target.checked)}/> auto</label>
              </div>
            </div>

            {tab==='timbra' && (
              <div className="mt-5 grid gap-4">
                <div className="rounded-[20px] bg-white border-2 border-[#ffcc00] p-6 shadow-soft">
                  <h2 className="cond font-bold text-[24px] text-[#0f2c5c]">Timbratura — entro 150m da sede</h2>
                  <p className="text-[12px] text-black/60 mt-1">Sede: {SEDE.lat}, {SEDE.lng} • raggio {RAGGIO}m • GPS: {geo? `${geo.lat.toFixed(5)},${geo.lng.toFixed(5)} ±${Math.round(geo.acc)}m`:'in attesa'}</p>
                  <div className="mt-4 grid md:grid-cols-2 gap-3">
                    <button disabled={busy || !inRange} onClick={()=>doEvent('timbratura')} className={`btn-giant rounded-[18px] border-2 font-bold cond p-5 text-left ${inRange?'bg-emerald-500 border-emerald-600 text-white':'bg-zinc-100 border-zinc-300 text-zinc-500'}`}>
                      <div className="text-[13px] uppercase">📍 Timbra Entrata</div>
                      <div className="text-[26px]">{inRange?'CONFERMA TIMBRATURA':'FUORI RAGGIO'}</div>
                      <div className="text-[12px] font-normal">{distance!==null?`${Math.round(distance)}m da sede`:'GPS mancante'}</div>
                    </button>
                    <button disabled={busy} onClick={()=>doEvent('fine_servizio')} className="btn-giant rounded-[18px] bg-[#0f2c5c] text-white border-2 border-[#0a1e40] p-5 text-left font-bold cond">
                      <div className="text-[13px] uppercase opacity-80">🏁 Fine</div>
                      <div className="text-[26px]">FINE SERVIZIO</div>
                      <div className="text-[12px] font-normal opacity-80">Chiude turno</div>
                    </button>
                  </div>
                  <div className="mt-4 flex gap-2">
                    <button disabled={busy} onClick={()=>doEvent('posizione','Manuale')} className="rounded-xl bg-white border-2 border-[#0f2c5c] px-4 py-2.5 text-[12px] font-bold uppercase text-[#0f2c5c]">📍 Invia posizione ora</button>
                    <span className="text-[11px] text-black/60 self-center">Auto tra {posCountdown} — log sotto</span>
                  </div>
                  <div className="mt-4 max-h-[160px] overflow-auto border-t border-dashed pt-3 space-y-1">
                    {posLogs.map((l,i)=><div key={i} className="text-[11px] flex justify-between border-b border-dashed py-1"><span>{l.volunteerName}</span><span>{fmtTime(l.ts)} {l.lat.toFixed(4)},{l.lng.toFixed(4)}</span></div>)}
                    {posLogs.length===0 && <div className="text-[11px] text-black/50">Nessun invio — primo tra {posCountdown}</div>}
                  </div>
                </div>
                <div className="rounded-[20px] bg-[#0f2c5c] text-white p-4 border-2 border-[#0a1e40] text-[12px]">Ultime timbrature del gruppo {groupCode}: {filteredEvents.filter(e=>e.value.type==='timbratura').slice(0,3).map(e=> `${e.value.volunteerName} ${fmtTime(e.value.ts)}`).join(' • ') || 'nessuna'}</div>
              </div>
            )}

            {tab==='emergenza' && (
              <div className="mt-5">
                <div className="rounded-[22px] bg-[#E11D48] text-white p-6 border-2 border-red-700 shadow-soft">
                  <h2 className="cond font-bold text-[28px]">🚨 Emergenza — sempre disponibile</h2>
                  <p className="text-[13px] opacity-90 mt-2">Non serve essere in sede. Cooldown 30 minuti reali tra segnalazioni.</p>
                  <div className="mt-5">
                    <button disabled={busy || !canEmergency} onClick={()=>doEvent('emergenza','Emergenza da app')} className={`w-full btn-giant rounded-[18px] border-2 font-black text-[22px] ${canEmergency?'bg-white text-[#E11D48] border-white':'bg-zinc-300 text-zinc-500 border-zinc-400'}`}>{canEmergency?'SEGNALA EMERGENZA ORA':'ATTENDI '+ (emergencyCountdown||'')}</button>
                  </div>
                  <div className="mt-3 text-[11px] opacity-90">{lastEmergency?`Ultima emergenza: ${fmtTime(lastEmergency)} — prossimo tra ${emergencyCountdown||'ora'}`:'Nessuna emergenza recente'}</div>
                </div>
                <div className="mt-4 rounded-[16px] bg-white border border-[var(--line)] p-4">
                  <h3 className="cond font-bold text-[16px]">Storico emergenze — {groupCode}</h3>
                  <div className="mt-2 space-y-1 max-h-[200px] overflow-auto">
                    {filteredEvents.filter(e=>e.value.type==='emergenza').map(ev=>(
                      <div key={ev.id} className="text-[12px] flex justify-between border-b border-dashed py-1"><span>{ev.value.volunteerName}: {ev.value.note||'emergenza'}</span><span>{fmtTime(ev.value.ts)} {ev.value.lat?`${ev.value.lat.toFixed(4)},${ev.value.lng?.toFixed(4)}`:''}</span></div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {tab==='home' && (
              <div className="mt-5 grid gap-4">
                <div className="grid md:grid-cols-3 gap-4">
                  <button disabled={busy} onClick={()=>doEvent('timbratura')} className={`btn-giant rounded-[22px] border-2 font-bold cond shadow-soft text-left p-5 flex flex-col justify-between ${inRange?'bg-emerald-500 border-emerald-600 text-white':'bg-white border-[var(--line)] text-black'}`}>
                    <div className="text-[13px] uppercase tracking-wide">📍 Timbratura</div>
                    <div className="text-[28px] leading-none">{inRange?'TIMBRA ENTRATA':'FUORI SEDE'}</div>
                    <div className="text-[12px] font-normal normal-case opacity-80">{distance!==null?`${Math.round(distance)}m da sede — raggio ${RAGGIO}m`:'In attesa GPS...'}</div>
                  </button>

                  <button disabled={busy} onClick={()=>doEvent('fine_servizio')} className="btn-giant rounded-[22px] bg-[#0f2c5c] text-white border-2 border-[#0a1e40] shadow-soft text-left p-5 flex flex-col justify-between">
                    <div className="text-[13px] uppercase tracking-wide opacity-80">🏁 Servizio</div>
                    <div className="text-[28px] leading-none">FINE SERVIZIO</div>
                    <div className="text-[12px] font-normal normal-case opacity-80">Chiude turno e registra orario</div>
                  </button>

                  <button disabled={busy || !canEmergency} onClick={()=>doEvent('emergenza','Emergenza da app')} className={`btn-giant rounded-[22px] border-2 shadow-soft text-left p-5 flex flex-col justify-between ${canEmergency?'bg-[#E11D48] border-red-700 text-white':'bg-zinc-200 border-zinc-300 text-zinc-500'}`}>
                    <div className="text-[13px] uppercase tracking-wide">🚨 Emergenza — 30 min reali</div>
                    <div className="text-[28px] leading-none">{canEmergency?'SEGNALA EMERGENZA':'ATTESA 30 MIN'}</div>
                    <div className="text-[12px] font-normal normal-case opacity-90">{emergencyCountdown ? `Prossimo tra: ${emergencyCountdown}` : lastEmergency?`Ultima ${fmtTime(lastEmergency)}`:'Nessuna recente'}</div>
                  </button>
                </div>

                <div className="grid md:grid-cols-[1.2fr_0.8fr] gap-4">
                  <div className="rounded-[20px] bg-white border-2 border-[#ffcc00] p-5 shadow-soft">
                    <div className="flex items-center justify-between">
                      <h3 className="cond font-bold text-[18px] text-[#0f2c5c]">Richieste Ferie / Reperibilità</h3>
                      <span className={`text-[11px] border-2 rounded-full px-2 py-1 uppercase font-black ${syncState==='sync'?'bg-emerald-100 border-emerald-600 text-emerald-800': syncState==='npoint'?'bg-blue-100 border-blue-600 text-blue-800':'bg-amber-100 border-amber-600 text-amber-800'}`}>{syncState}</span>
                    </div>
                    <div className="mt-4 grid grid-cols-[110px_1fr_1fr_auto] gap-2">
                      <select value={ferieTipo} onChange={e=>setFerieTipo(e.target.value as any)} className="rounded-xl border-2 border-[#ffcc00] bg-white px-3 py-2.5 text-[13px] text-black"><option value="ferie">Ferie</option><option value="reperibilita">Reperibilità</option></select>
                      <input type="date" value={ferieFrom} onChange={e=>setFerieFrom(e.target.value)} className="rounded-xl border border-[var(--line)] bg-white px-3 py-2.5 text-[13px] text-black"/>
                      <input type="date" value={ferieTo} onChange={e=>setFerieTo(e.target.value)} className="rounded-xl border border-[var(--line)] bg-white px-3 py-2.5 text-[13px] text-black"/>
                      <button onClick={sendRequest} className="rounded-xl bg-[#0f2c5c] text-white px-4 py-2.5 text-[12px] font-bold uppercase">Invia</button>
                    </div>
                    <div className="mt-4 space-y-1 max-h-[160px] overflow-auto">
                      {filteredRequests.map(r=>(
                        <div key={r.id} className="flex items-center justify-between rounded-xl border border-[var(--line)] bg-[var(--surface-2)] px-3 py-2 text-[12px]">
                          <span><b>{r.value.volunteerName}</b> {r.value.type} {r.value.from} → {r.value.to} <i className="opacity-70">{r.value.status}</i></span>
                          {(currentUser.value.role==='coordinatore' || currentUser.value.role==='servizio') && r.value.status==='in_attesa' && (
                            <span className="flex gap-1">
                              <button onClick={()=>approveRequest(r.id,'approvata')} className="text-[10px] rounded-full bg-emerald-500 text-white px-2 py-1 font-bold">OK</button>
                              <button onClick={()=>approveRequest(r.id,'rifiutata')} className="text-[10px] rounded-full bg-red-500 text-white px-2 py-1 font-bold">NO</button>
                            </span>
                          )}
                        </div>
                      ))}
                      {filteredRequests.length===0 && <div className="text-[11px] text-black/50">Nessuna richiesta per {groupCode}</div>}
                    </div>
                  </div>

                  <div className="rounded-[20px] bg-white border border-[var(--line)] p-5 shadow-soft">
                    <h3 className="cond font-bold text-[16px] text-[#0f2c5c]">Log Posizione — 30 min reali FIX</h3>
                    <div className="mt-2 flex items-center gap-2 text-[11px]"><span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse"/>Prossimo invio tra: <b>{posCountdown}</b> <span className="ml-auto">Auto: {posEnabled?'ON':'OFF'}</span></div>
                    <div className="mt-3 max-h-[160px] overflow-auto space-y-1">
                      {posLogs.map((l,i)=><div key={i} className="text-[11px] flex justify-between border-b border-dashed py-1"><span>{l.volunteerName}</span><span className="font-mono">{fmtTime(l.ts)}</span></div>)}
                      {posLogs.length===0 && <div className="text-[11px] text-black/50">In attesa primo invio — tra {posCountdown}</div>}
                    </div>
                    <div className="mt-3 rounded-xl bg-[#0f2c5c] text-white p-3 text-[11px]">Intervallo reale: <b>1800000 ms = 30 min</b> (prima demo 30 sec). Countdown visibile e log timestamp mantenuti.</div>
                  </div>
                </div>

                {(currentUser.value.role==='coordinatore' || currentUser.value.role==='servizio') && (
                  <div className="mt-2 border-t border-[var(--line)] pt-5">
                    <div className="cond font-bold text-[18px]">Gestione Volontari — Modifica / Aggiungi (PIN non visibili in login)</div>
                    <div className="mt-3 grid md:grid-cols-[1fr_1fr_140px_100px_auto] gap-2 items-end">
                      <input placeholder="Nome" value={editingVol ? editingVol.value.name : newVol.name} onChange={e=> editingVol ? setEditingVol({...editingVol, value:{...editingVol.value, name:e.target.value}}) : setNewVol({...newVol, name:e.target.value})} className="rounded-xl border border-[var(--line)] bg-white px-3 py-2.5 text-sm text-black"/>
                      <input placeholder="PIN" value={editingVol ? editingVol.value.pin : newVol.pin} onChange={e=> editingVol ? setEditingVol({...editingVol, value:{...editingVol.value, pin:e.target.value}}) : setNewVol({...newVol, pin:e.target.value})} className="rounded-xl border border-[var(--line)] bg-white px-3 py-2.5 text-sm text-black"/>
                      <select value={editingVol ? editingVol.value.role : newVol.role} onChange={e=> editingVol ? setEditingVol({...editingVol, value:{...editingVol.value, role:e.target.value as Role}}) : setNewVol({...newVol, role:e.target.value as Role})} className="rounded-xl border border-[var(--line)] bg-white px-3 py-2.5 text-sm text-black">
                        <option value="volontario">volontario</option><option value="coordinatore">coordinatore</option><option value="servizio">servizio</option>
                      </select>
                      <label className="flex items-center gap-1 text-[12px]"><input type="checkbox" checked={editingVol ? editingVol.value.active : newVol.active} onChange={e=> editingVol ? setEditingVol({...editingVol, value:{...editingVol.value, active:e.target.checked}}) : setNewVol({...newVol, active:e.target.checked})}/> attivo</label>
                      <div className="flex gap-2">
                        <button onClick={upsertVolunteer} className="rounded-xl bg-[#0f2c5c] text-white px-4 py-2.5 text-[12px] font-bold uppercase">{editingVol?'Salva':'Aggiungi'}</button>
                        {editingVol && <button onClick={()=>setEditingVol(null)} className="rounded-xl border px-3 py-2.5 text-[12px] bg-white text-black">Annulla</button>}
                      </div>
                    </div>
                    <div className="mt-4 grid md:grid-cols-2 gap-2">
                      {volunteers.map(v=>(
                        <div key={v.id} className="flex items-center justify-between rounded-xl border border-[var(--line)] bg-[var(--surface-2)] px-3 py-2">
                          <div className="text-[13px]"><b>{v.value.name}</b> <span className="text-[11px] opacity-70">({v.value.role}) {v.value.active?'':'— disattivo'}</span></div>
                          <div className="flex gap-1">
                            <button onClick={()=>setEditingVol(v)} className="text-[11px] rounded-full bg-white border px-2 py-1 text-black">Modifica</button>
                            <button onClick={()=>deleteVolunteer(v.id)} className="text-[11px] rounded-full bg-red-50 border border-red-200 text-red-700 px-2 py-1">Elimina</button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {tab==='chat' && (
              <div className="mt-5 rounded-[20px] bg-white border border-[var(--line)] shadow-soft overflow-hidden flex flex-col h-[56vh]">
                <div className="flex items-center justify-between p-4 border-b-2 border-[#ffcc00] bg-[var(--surface-2)]">
                  <h2 className="cond font-bold text-[20px] text-[#0f2c5c]">Chat Squadra — {groupCode}</h2>
                  <span className="text-[11px] px-2 py-1 rounded-full bg-[#0f2c5c] border border-white text-white font-bold">● LIVE {posCountdown}</span>
                </div>
                <div className="flex-1 overflow-auto p-4 space-y-3 bg-[#f6f8fc]">
                  {filteredChats.map(c=>(
                    <div key={c.id} className={`max-w-[78%] rounded-[16px] px-4 py-2 text-[13px] ${c.value.volunteerId===currentUser?.id ? 'ml-auto bg-[#0f2c5c] text-white border-2 border-[#0a1e40]' : 'bg-white border-2 border-[#ffcc00] text-black'}`}>
                      <div className="text-[10px] uppercase opacity-70 font-bold">{c.value.volunteerName} • {fmtTime(c.value.ts)}</div>
                      <div className="mt-1">{c.value.message}</div>
                    </div>
                  ))}
                  {filteredChats.length===0 && <div className="text-[12px] text-black/60">Nessun messaggio per questo gruppo. Scrivi il primo!</div>}
                </div>
                <div className="p-3 border-t-2 border-[#ffcc00] flex gap-2 bg-white">
                  <input value={chatMsg} onChange={e=>setChatMsg(e.target.value)} onKeyDown={e=> e.key==='Enter' && sendChat()} placeholder="Messaggio a tutta la squadra..." className="flex-1 rounded-full border-2 border-[#ffcc00] bg-white px-4 py-3 text-[14px] text-black"/>
                  <button onClick={sendChat} className="rounded-full bg-[#0f2c5c] text-white px-6 py-3 font-bold text-[13px] uppercase border-2 border-[#0a1e40]">Invia</button>
                </div>
              </div>
            )}

            {tab==='schede' && (
              <div className="mt-5 space-y-4">
                <div className="flex flex-wrap items-center gap-3">
                  <h2 className="cond text-[26px] font-bold text-[#0f2c5c]">Schede Mese per Mese — Presenze</h2>
                  <div className="flex items-center gap-2 rounded-full bg-white border-2 border-[#ffcc00] px-2 py-1">
                    <button onClick={()=>{ if(month===0){setMonth(11); setYear(y=>y-1);} else setMonth(m=>m-1); }} className="h-8 w-8 grid place-items-center rounded-full bg-[#ffcc00] text-[#0f2c5c] font-bold border">‹</button>
                    <span className="px-3 text-[13px] font-bold uppercase text-black">{new Date(year,month).toLocaleDateString('it-IT',{month:'long',year:'numeric'})}</span>
                    <button onClick={()=>{ if(month===11){setMonth(0); setYear(y=>y+1);} else setMonth(m=>m+1); }} className="h-8 w-8 grid place-items-center rounded-full bg-[#ffcc00] text-[#0f2c5c] font-bold border">›</button>
                  </div>
                </div>

                <div className="grid md:grid-cols-3 gap-3">
                  {volunteers.filter(v=>v.value.active).map(vol=>{
                    const evs = monthEvents.filter(e=> e.value.volunteerId===vol.id);
                    const timb = evs.filter(e=>e.value.type==='timbratura').length;
                    const fines = evs.filter(e=>e.value.type==='fine_servizio').length;
                    const emerg = evs.filter(e=>e.value.type==='emergenza').length;
                    const pos = evs.filter(e=>e.value.type==='posizione').length;
                    return (
                      <div key={vol.id} className="rounded-[18px] bg-white border-2 border-[#0f2c5c] p-4 shadow-soft">
                        <div className="flex justify-between items-start">
                          <div><b className="text-[14px] text-black">{vol.value.name}</b><div className="text-[11px] uppercase text-black/60">{vol.value.role} • pos {pos}</div></div>
                          <div className="text-[11px] rounded-full bg-[#ffcc00] border-2 border-[#0f2c5c] px-2 py-1 font-black text-[#0f2c5c]">{timb} timb.</div>
                        </div>
                        <div className="mt-3 grid grid-cols-4 gap-2 text-[11px] text-center">
                          <div className="rounded-xl bg-emerald-50 border-2 border-emerald-600 py-2 text-black"><b className="block text-[16px]">{timb}</b>Entrate</div>
                          <div className="rounded-xl bg-blue-50 border-2 border-blue-600 py-2 text-black"><b className="block text-[16px]">{fines}</b>Uscite</div>
                          <div className="rounded-xl bg-red-50 border-2 border-red-600 py-2 text-black"><b className="block text-[16px]">{emerg}</b>Emerg.</div>
                          <div className="rounded-xl bg-amber-50 border-2 border-amber-600 py-2 text-black"><b className="block text-[16px]">{pos}</b>Pos</div>
                        </div>
                        <div className="mt-3 space-y-1 max-h-[110px] overflow-auto">
                          {evs.slice(0,10).map(e=>(
                            <div key={e.id} className="text-[11px] flex justify-between border-b border-dashed border-[var(--line)] py-1 text-black"><span>{fmtDate(e.value.ts)} {e.value.type}</span><span className="font-mono">{new Date(e.value.ts).toLocaleTimeString('it-IT',{hour:'2-digit',minute:'2-digit'})}</span></div>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>

                <div className="rounded-[16px] bg-[#0f2c5c] text-white p-4 text-[12px] border-2 border-[#0a1e40]">Dati filtrati per gruppo <b>{groupCode}</b>. Posizioni ogni 30 min reali — countdown {posCountdown}. Sync: {syncModeLabel}</div>
              </div>
            )}
          </>
        )}
      </main>

      {currentUser && (
        <nav className="fixed bottom-0 inset-x-0 z-30 border-t-2 border-[#ffcc00] bg-white/95 glass">
          <div className="mx-auto max-w-[1080px] grid grid-cols-5 gap-1 px-2 py-2">
            {[
              {k:'home', l:'Home', i:'🏠'},
              {k:'timbra', l:'Timbra', i:'📍'},
              {k:'emergenza', l:'SOS', i:'🚨'},
              {k:'chat', l:'Chat', i:'💬'},
              {k:'schede', l:'Schede', i:'🗓️'},
            ].map(item=>(
              <button key={item.k} onClick={()=>setTab(item.k as any)} className={`flex flex-col items-center justify-center rounded-[14px] py-2.5 border-2 ${tab===item.k ? 'bg-[#0f2c5c] text-white border-[#0a1e40] shadow-soft' : 'text-black bg-white border-[#ffcc00]'}`}>
                <span className="text-[18px] leading-none">{item.i}</span>
                <span className="mt-1 text-[10px] font-bold uppercase tracking-wide">{item.l}</span>
              </button>
            ))}
          </div>
          <div className="h-[env(safe-area-inset-bottom)] bg-white" />
        </nav>
      )}

      <div className="pointer-events-none fixed bottom-[96px] right-3 hidden md:block rounded-full bg-[#ffcc00] px-3 py-1 text-[11px] font-black uppercase shadow-soft border-2 border-[#0f2c5c] text-[#0f2c5c]">FIX 30min • {posCountdown} • {syncState}</div>
    </div>
  );
}

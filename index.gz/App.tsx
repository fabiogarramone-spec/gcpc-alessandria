import { useEffect, useState, useRef, useMemo } from 'react';
import logoUrl from "container:///mnt/data/src/assets/739202fb338e864d-Protezione_Civile_Logo";

// --- Types ---
type Role = 'volontario' | 'coordinatore' | 'servizio';
type Volunteer = { name: string; pin: string; role: Role; active: boolean; };
type EventType = 'timbratura' | 'fine_servizio' | 'emergenza';
type EventRec = { type: EventType; volunteerId: string; volunteerName: string; lat?: number; lng?: number; distance?: number; ts: number; note?: string; groupCode?: string };
type ChatRec = { volunteerId: string; volunteerName: string; message: string; ts: number; groupCode?: string };
type RequestRec = { type: 'ferie' | 'reperibilita'; volunteerId: string; volunteerName: string; from: string; to: string; status: 'in_attesa'|'approvata'|'rifiutata'; ts: number; groupCode?: string };
type SettingsRec = { groupCode: string; motto: string; firebase?: { apiKey: string; projectId: string }; };

const SEDE = { lat: 44.897036, lng: 8.597517 };
const RAGGIO = 150;
const EMERGENCY_COOLDOWN = 30 * 60 * 1000;
const NPOINT_ENDPOINT = "https://api.npoint.io";
const NPOINT_DOC = "https://api.npoint.io - JSON bin gratuito per sync gruppo";
const MOTTO_DEFAULT = "ALACRI, PRONTI, OVUNQUE - PROTEZIONE CIVILE ALESSANDRIA";

function haversine(lat1:number, lon1:number, lat2:number, lon2:number){
  const R=6371000;
  const dLat=(lat2-lat1)*Math.PI/180;
  const dLon=(lon2-lon1)*Math.PI/180;
  const a=Math.sin(dLat/2)**2 + Math.cos(lat1*Math.PI/180)*Math.cos(lat2*Math.PI/180)*Math.sin(dLon/2)**2;
  return 2*R*Math.asin(Math.sqrt(a));
}
function fmtTime(ts:number){ return new Date(ts).toLocaleString('it-IT',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}); }
function fmtDate(ts:number){ return new Date(ts).toLocaleDateString('it-IT',{weekday:'short', day:'2-digit', month:'short'}); }

async function api(action:string, args:any){
  const res = await fetch("actions", { method:"POST", headers:{ "content-type":"application/json" }, body: JSON.stringify({ action, args }) });
  const j = await res.json();
  if(!res.ok || j.error) throw new Error(j.error || `HTTP ${res.status}`);
  return j.data;
}

export default function App(){
  const [volunteers, setVolunteers] = useState<{id:string, value:Volunteer}[]>([]);
  const [events, setEvents] = useState<{id:string,value:EventRec}[]>([]);
  const [chats, setChats] = useState<{id:string,value:ChatRec}[]>([]);
  const [requests, setRequests] = useState<{id:string,value:RequestRec}[]>([]);
  const [settings, setSettings] = useState<{id:string,value:SettingsRec}|null>(null);

  const [syncState, setSyncState] = useState<'sync'|'offline'|'error'>('offline');
  const [lastSync, setLastSync] = useState<number|null>(null);
  const [busy, setBusy] = useState(false);
  const [currentUser, setCurrentUser] = useState<{id:string,value:Volunteer}|null>(null);
  const [loginSelect, setLoginSelect] = useState('');
  const [pinInput, setPinInput] = useState('');
  const [loginError, setLoginError] = useState('');
  const [tab, setTab] = useState<'home'|'timbra'|'emergenza'|'chat'|'schede'>('home');
  const [month, setMonth] = useState(new Date().getMonth());
  const [year, setYear] = useState(new Date().getFullYear());
  const [chatMsg, setChatMsg] = useState('');
  const [ferieFrom, setFerieFrom] = useState('');
  const [ferieTo, setFerieTo] = useState('');
  const [ferieTipo, setFerieTipo] = useState<'ferie'|'reperibilita'>('ferie');
  const [groupInput, setGroupInput] = useState('PC-AL-2024');
  const [showSettings, setShowSettings] = useState(false);
  const [fbApi, setFbApi] = useState('');
  const [fbProject, setFbProject] = useState('');
  const [editingVol, setEditingVol] = useState<{id:string, value:Volunteer}|null>(null);
  const [newVol, setNewVol] = useState<Volunteer>({ name:'', pin:'', role:'volontario', active:true });
  const [geo, setGeo] = useState<{lat:number,lng:number,acc:number}|null>(null);
  const [geoErr, setGeoErr] = useState('');
  const [statusMsg, setStatusMsg] = useState('');
  const [showPinPad, setShowPinPad] = useState(false);

  const bcRef = useRef<BroadcastChannel|null>(null);

  const groupCode = settings?.value.groupCode || 'PC-AL-2024';
  const filteredEvents = useMemo(()=> events.filter(e=> !e.value.groupCode || e.value.groupCode===groupCode), [events,groupCode]);
  const filteredChats = useMemo(()=> chats.filter(c=> !c.value.groupCode || c.value.groupCode===groupCode), [chats,groupCode]);
  const filteredRequests = useMemo(()=> requests.filter(r=> !r.value.groupCode || r.value.groupCode===groupCode), [requests,groupCode]);

  async function reload(){
    try{
      const [v,e,c,r,s] = await Promise.all([
        api('records.list',{collection:'volunteers'}),
        api('records.list',{collection:'events'}),
        api('records.list',{collection:'chats'}),
        api('records.list',{collection:'requests'}),
        api('records.list',{collection:'settings'}),
      ]);
      setVolunteers(v.records);
      setEvents(e.records.sort((a:any,b:any)=>b.value.ts-a.value.ts));
      setChats(c.records.sort((a:any,b:any)=>a.value.ts-b.value.ts));
      setRequests(r.records.sort((a:any,b:any)=>b.value.ts-a.value.ts));
      if(s.records[0]){ setSettings(s.records[0]); setGroupInput(s.records[0].value.groupCode); }
      else {
        const def:SettingsRec={groupCode:'PC-AL-2024', motto:MOTTO_DEFAULT};
        const created = await api('records.create',{collection:'settings', value:def});
        setSettings(created);
      }
      setSyncState('sync');
      setLastSync(Date.now());
      if(v.records.length===0){
        const seeds:Volunteer[]=[
          { name:'Coordinatore Rossi', pin:'1234', role:'coordinatore', active:true },
          { name:'Servizio Centrale', pin:'0000', role:'servizio', active:true },
          { name:'Bianchi Marco', pin:'1111', role:'volontario', active:true },
          { name:'Ferrari Anna', pin:'2222', role:'volontario', active:true },
          { name:'Esposito Luca', pin:'3333', role:'volontario', active:true },
        ];
        for(const s of seeds){ await api('records.create',{collection:'volunteers', value:s}); }
        const rev = await api('records.list',{collection:'volunteers'});
        setVolunteers(rev.records);
      }
    }catch(err){
      console.warn(err);
      setSyncState('offline');
    }
  }

  useEffect(()=>{
    reload();
    const id = setInterval(reload, 15000);
    try{
      bcRef.current = new BroadcastChannel('pc-al-sync');
      bcRef.current.onmessage = (ev)=>{ if(ev.data==='reload') reload(); };
    }catch{}
    return ()=>{ clearInterval(id); bcRef.current?.close(); };
  },[]);

  useEffect(()=>{
    if(!navigator.geolocation) { setGeoErr('GPS non disponibile'); return; }
    const watch = navigator.geolocation.watchPosition((p)=>{
      setGeo({lat:p.coords.latitude,lng:p.coords.longitude,acc:p.coords.accuracy});
      setGeoErr('');
    }, (e)=> setGeoErr(e.message), {enableHighAccuracy:true});
    return ()=> navigator.geolocation.clearWatch(watch);
  },[]);

  const distance = geo ? haversine(geo.lat, geo.lng, SEDE.lat, SEDE.lng) : null;
  const inRange = distance!==null && distance<=RAGGIO;

  const lastEmergency = useMemo(()=>{
    if(!currentUser) return null;
    const ev = filteredEvents.find(e=> e.value.type==='emergenza' && e.value.volunteerId===currentUser.id);
    return ev?.value.ts || null;
  },[filteredEvents,currentUser]);

  const canEmergency = !lastEmergency || (Date.now() - lastEmergency) > EMERGENCY_COOLDOWN;

  async function handleLogin(){
    setLoginError('');
    const vol = volunteers.find(v=> v.id===loginSelect);
    if(!vol){ setLoginError('Seleziona un nominativo'); return; }
    if(vol.value.pin !== pinInput){ setLoginError('PIN errato'); return; }
    if(!vol.value.active){ setLoginError('Utente disattivato'); return; }
    setCurrentUser(vol);
    setTab('home');
    setShowPinPad(false);
  }

  async function doEvent(type:EventType, note?:string){
    if(!currentUser) return;
    setBusy(true);
    try{
      const rec:EventRec={ type, volunteerId:currentUser.id, volunteerName:currentUser.value.name, lat:geo?.lat, lng:geo?.lng, distance: distance||undefined, ts:Date.now(), note, groupCode };
      await api('records.create',{collection:'events', value:rec, idempotency_key: `${type}-${currentUser.id}-${Date.now()}`});
      setStatusMsg(type==='emergenza' ? '🚨 Emergenza segnalata!' : type==='timbratura' ? '✅ Timbratura registrata' : '🏁 Fine servizio');
      bcRef.current?.postMessage('reload');
      await reload();
      setTimeout(()=>setStatusMsg(''),3000);
    }catch(e:any){ setStatusMsg('Errore: '+e.message); }
    setBusy(false);
  }

  async function sendChat(){
    if(!chatMsg.trim()||!currentUser) return;
    try{
      const rec:ChatRec={ volunteerId:currentUser.id, volunteerName:currentUser.value.name, message:chatMsg.trim(), ts:Date.now(), groupCode };
      await api('records.create',{collection:'chats', value:rec});
      setChatMsg('');
      bcRef.current?.postMessage('reload');
      await reload();
    }catch{}
  }

  async function sendRequest(){
    if(!ferieFrom||!ferieTo||!currentUser) return;
    try{
      const rec:RequestRec={ type:ferieTipo, volunteerId:currentUser.id, volunteerName:currentUser.value.name, from:ferieFrom, to:ferieTo, status:'in_attesa', ts:Date.now(), groupCode };
      await api('records.create',{collection:'requests', value:rec});
      setFerieFrom(''); setFerieTo('');
      setStatusMsg('Richiesta inviata');
      await reload();
    }catch(e:any){ setStatusMsg(e.message); }
  }

  async function saveSettings(){
    try{
      const val:SettingsRec={ groupCode:groupInput.trim()||'PC-AL-2024', motto: settings?.value.motto || MOTTO_DEFAULT, firebase: fbApi ? {apiKey:fbApi, projectId:fbProject} : undefined };
      if(settings){ await api('records.replace',{collection:'settings', id:settings.id, value:val}); }
      else { const created = await api('records.create',{collection:'settings', value:val}); setSettings(created); }
      setSettings(s=> s? {...s, value:val} : s);
      setStatusMsg('Impostazioni salvate - Sync attiva');
      await reload();
      setShowSettings(false);
    }catch(e:any){ setStatusMsg(e.message); }
  }

  async function upsertVolunteer(){
    try{
      if(editingVol){
        await api('records.replace',{collection:'volunteers', id:editingVol.id, value:editingVol.value});
        setEditingVol(null);
      }else{
        if(!newVol.name||!newVol.pin) { setStatusMsg('Nome e PIN obbligatori'); return; }
        await api('records.create',{collection:'volunteers', value:newVol});
        setNewVol({name:'',pin:'',role:'volontario',active:true});
      }
      await reload();
    }catch(e:any){ setStatusMsg(e.message); }
  }

  async function deleteVolunteer(id:string){
    if(!confirm('Eliminare volontario?')) return;
    try{ await api('records.delete',{collection:'volunteers', id}); await reload(); }catch(e:any){ setStatusMsg(e.message); }
  }

  async function approveRequest(id:string, status:RequestRec['status']){
    const r = requests.find(x=>x.id===id);
    if(!r) return;
    try{ await api('records.replace',{collection:'requests', id, value:{...r.value, status}}); await reload(); }catch{}
  }

  // PIN pad handlers
  const pressDigit = (d:string)=>{
    if(pinInput.length>=4) return;
    setPinInput(p=> (p+d).slice(0,4));
  };
  const pressBack = ()=> setPinInput(p=> p.slice(0,-1));
  const pressClear = ()=> setPinInput('');

  const monthEvents = filteredEvents.filter(ev=>{
    const d=new Date(ev.value.ts);
    return d.getMonth()===month && d.getFullYear()===year;
  });

  return (
    <div data-safe-area-inset-root className="min-h-[100dvh] w-full bg-[var(--bg)] text-[var(--text)] overflow-x-clip" style={{boxSizing:'border-box', paddingTop:'var(--safe-area-inset-top)'}}>
      <style>{`
        .glass { backdrop-filter: blur(18px); -webkit-backdrop-filter: blur(18px); }
        .btn-giant { min-height: 88px; font-size: 1.35rem; letter-spacing:.02em; }
        .shadow-soft { box-shadow: 0 8px 30px rgba(12,45,94,.08); }
        /* FIX PIN INPUT - FORZATURA ALTA VISIBILITA */
        .pin-input-fix{
          color-scheme: light !important;
          background-color: #ffffff !important;
          background: #ffffff !important;
          color: #000000 !important;
          -webkit-text-fill-color: #000000 !important;
          caret-color: #000000 !important;
          border: 3px solid #ffcc00 !important;
          font-size: 24px !important;
          font-weight: 800 !important;
          height: 60px !important;
          letter-spacing: 0.45em !important;
          text-align: center;
        }
        .pin-input-fix::placeholder{
          color: #555555 !important;
          -webkit-text-fill-color: #555555 !important;
          opacity: 1 !important;
          letter-spacing: normal !important;
          font-size: 16px !important;
          font-weight: 600 !important;
        }
        .pin-input-fix:focus{
          background-color: #ffffff !important;
          color: #000000 !important;
          border-color: #ffcc00 !important;
          box-shadow: 0 0 0 4px rgba(255,204,0,0.35), 0 6px 20px rgba(0,0,0,0.12) !important;
          outline: none !important;
        }
        /* keypad */
        .key-yellow{
          background: #ffcc00 !important;
          color: #0f2c5c !important;
          border: 2px solid #e6b800 !important;
          box-shadow: 0 4px 0 #c49c00, 0 8px 18px rgba(0,0,0,0.18) !important;
        }
        .key-yellow:active{
          transform: translateY(2px);
          box-shadow: 0 2px 0 #c49c00, 0 4px 10px rgba(0,0,0,0.18) !important;
        }
        .key-blue{
          background: #0f2c5c !important;
          color: #ffffff !important;
          border: 2px solid #0a1e40 !important;
          box-shadow: 0 4px 0 #07132a, 0 8px 18px rgba(0,0,0,0.25) !important;
        }
        .key-white{
          background: #ffffff !important;
          color: #0f2c5c !important;
          border: 3px solid #ffcc00 !important;
          box-shadow: 0 4px 0 #ffcc00, 0 8px 18px rgba(0,0,0,0.12) !important;
        }
      `}</style>

      <header data-safe-area-sticky-top className="sticky z-30 bg-[var(--surface)]/90 glass border-b border-[var(--line)]" style={{top:'var(--safe-area-inset-top)'}}>
        <div className="mx-auto max-w-[1080px] px-4 h-[64px] flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <img src={logoUrl} alt="Protezione Civile" className="h-[42px] w-[42px] object-contain rounded-full bg-white p-1 shadow-soft"/>
            <div className="leading-none">
              <div className="cond font-bold text-[18px] text-[var(--pc-blue)] tracking-wide">P.C. ALESSANDRIA</div>
              <div className="text-[10px] font-semibold text-[var(--text-muted)] uppercase tracking-[0.18em]">{settings?.value.motto || MOTTO_DEFAULT}</div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5 rounded-full border border-[var(--line)] bg-[var(--surface-2)] px-3 py-1.5">
              <span className={`h-2.5 w-2.5 rounded-full ${syncState==='sync' ? 'bg-emerald-500 animate-pulse' : syncState==='offline' ? 'bg-amber-400' : 'bg-red-500'}`}/>
              <span className="text-[11px] font-semibold uppercase tracking-wide">
                {syncState==='sync' ? `Sincronizzato ${lastSync? new Date(lastSync).toLocaleTimeString('it-IT',{hour:'2-digit',minute:'2-digit'}):''}` : syncState==='offline' ? 'Offline' : 'Non sincronizzato'}
              </span>
            </div>
            {currentUser && (
              <button onClick={()=>setShowSettings(!showSettings)} className="h-9 w-9 grid place-items-center rounded-full bg-[var(--pc-blue)] text-white">⚙</button>
            )}
          </div>
        </div>
      </header>

      {statusMsg && (
        <div className="fixed left-1/2 -translate-x-1/2 top-[80px] z-50 rounded-full bg-[var(--text)] text-white px-5 py-2 text-sm shadow-xl">{statusMsg}</div>
      )}

      <main className="mx-auto max-w-[1080px] px-4 pb-[96px] pt-4">
        {!currentUser ? (
          <div className="grid md:grid-cols-[1.1fr_0.9fr] gap-6 mt-2">
            <div className="rounded-[28px] bg-[var(--surface)] border border-[var(--line)] shadow-soft p-6 md:p-8">
              <div className="inline-flex items-center gap-2 rounded-full bg-[var(--pc-yellow)] px-3 py-1 text-[11px] font-bold uppercase tracking-wide text-[var(--pc-blue)]">Accesso Volontari - Alessandria</div>
              <h1 className="cond mt-4 text-[42px] leading-[0.9] font-bold">Accedi al<br/>Servizio</h1>
              <p className="mt-3 text-sm text-[var(--text-muted)]">Seleziona il tuo nominativo. Il PIN non è mai visibile in lista. Usa il tastierino giallo qui sotto, ben visibile anche al sole.</p>

              <div className="mt-7 space-y-5">
                <div>
                  <label className="text-[11px] font-bold uppercase tracking-wide text-[var(--text-muted)]">Volontario / Ruolo</label>
                  <select value={loginSelect} onChange={e=>setLoginSelect(e.target.value)} className="mt-1 w-full rounded-[14px] border border-[var(--line)] bg-white px-4 py-3.5 text-[16px] font-medium text-black">
                    <option value="">— Seleziona nominativo —</option>
                    {volunteers.map(v=>(
                      <option key={v.id} value={v.id}>{v.value.name} — {v.value.role}</option>
                    ))}
                  </select>
                  <p className="mt-2 text-[11px] text-[var(--text-muted)]">🔒 I PIN non sono mostrati per sicurezza.</p>
                </div>

                <div>
                  <label className="text-[11px] font-bold uppercase tracking-wide text-[var(--text-muted)] flex items-center justify-between">
                    <span>PIN personale (4 cifre) — tocca per aprire tastierino</span>
                    <span className="text-[10px] bg-[#ffcc00] text-[#0f2c5c] px-2 py-0.5 rounded-full font-black border border-[#0f2c5c]">ALTO CONTRASTO</span>
                  </label>
                  <div className="mt-2 relative">
                    <input
                      readOnly
                      inputMode="numeric"
                      pattern="[0-9]*"
                      value={pinInput}
                      onClick={()=>setShowPinPad(true)}
                      onFocus={()=>setShowPinPad(true)}
                      placeholder="TOCCA QUI • 4 CIFRE"
                      className="pin-input-fix w-full rounded-[14px] px-4 py-2 text-[24px]"
                      style={{backgroundColor:'#ffffff', color:'#000000', border:'3px solid #ffcc00', height:'60px'}}
                    />
                    <div className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 rounded-full bg-[#0f2c5c] text-white text-[11px] font-bold px-2 py-1">⌨️</div>
                  </div>
                  <div className="mt-2 flex gap-2 text-[10px] font-bold uppercase tracking-wide">
                    <span className="rounded-full bg-[#ffcc00] text-[#0f2c5c] border-2 border-[#0f2c5c] px-2.5 py-1">Bianco #fff • Testo #000</span>
                    <span className="rounded-full bg-white text-black border-2 border-[#ffcc00] px-2.5 py-1">Bordo 3px giallo</span>
                  </div>
                </div>

                {/* CUSTOM KEYPAD */}
                {showPinPad && (
                  <div className="rounded-[22px] border-[3px] border-[#ffcc00] bg-white p-4 shadow-[0_12px_40px_rgba(0,0,0,0.22)]">
                    <div className="flex items-center justify-between mb-3">
                      <div className="text-[12px] font-black uppercase tracking-widest text-[#0f2c5c]">Tastierino PIN — Visibile al sole ☀️</div>
                      <button onClick={()=>setShowPinPad(false)} className="rounded-full bg-[#0f2c5c] text-white text-[11px] font-bold px-3 py-1">CHIUDI ✕</button>
                    </div>

                    <div className="grid grid-cols-3 gap-3">
                      {[1,2,3,4,5,6,7,8,9].map(n=>(
                        <button
                          key={n}
                          onClick={()=>pressDigit(String(n))}
                          className="key-yellow h-[60px] rounded-[14px] text-[28px] font-black tracking-wide"
                          style={{height:'60px'}}
                        >{n}</button>
                      ))}
                      <button onClick={pressClear} className="key-white h-[60px] rounded-[14px] text-[13px] font-black uppercase" style={{height:'60px'}}>CANC<br/>TUTTO</button>
                      <button onClick={()=>pressDigit('0')} className="key-yellow h-[60px] rounded-[14px] text-[28px] font-black" style={{height:'60px'}}>0</button>
                      <button onClick={pressBack} className="key-white h-[60px] rounded-[14px] text-[20px] font-black" style={{height:'60px'}}>⌫</button>
                    </div>

                    <div className="mt-3 grid grid-cols-2 gap-3">
                      <button onClick={pressBack} className="key-white h-[60px] rounded-[14px] text-[14px] font-black uppercase" style={{height:'60px'}}>⬅ Cancella</button>
                      <button onClick={()=>{ setShowPinPad(false); }} className="key-blue h-[60px] rounded-[14px] text-[15px] font-black uppercase tracking-wide" style={{height:'60px'}}>OK Conferma ✓</button>
                    </div>

                    <div className="mt-3 flex items-center justify-center gap-2">
                      {Array.from({length:4}).map((_,i)=>(
                        <div key={i} className={`h-[16px] w-[36px] rounded-full border-2 ${pinInput.length>i ? 'bg-[#0f2c5c] border-[#0f2c5c]' : 'bg-white border-[#ffcc00]'}`}/>
                      ))}
                      <span className="ml-2 text-[12px] font-bold text-[#0f2c5c]">{pinInput.length}/4</span>
                    </div>
                  </div>
                )}

                {loginError && <div className="rounded-xl bg-red-50 text-red-700 px-4 py-2 text-sm border border-red-200">{loginError}</div>}

                <button onClick={handleLogin} className="btn-giant w-full rounded-[16px] bg-[#0f2c5c] text-white font-bold cond text-[22px] shadow-soft border-2 border-[#0a1e40]">ENTRA IN SERVIZIO →</button>

                <div className="grid grid-cols-3 gap-2 text-[11px]">
                  <div className="rounded-xl bg-white p-3 border-[2px] border-[#ffcc00] shadow-sm"><b className="block text-[12px] text-[#0f2c5c]">📍 150mt</b>Timbratura solo in sede<br/>44.897036, 8.597517</div>
                  <div className="rounded-xl bg-white p-3 border-[2px] border-[#0f2c5c] shadow-sm"><b className="block text-[12px] text-[#0f2c5c]">🚨 30min</b>Emergenza ogni 30 minuti</div>
                  <div className="rounded-xl bg-[#ffcc00] p-3 border-[2px] border-[#0f2c5c] shadow-sm text-[#0f2c5c]"><b className="block text-[12px]">🔄 Sync</b>Reale su tutti i dispositivi</div>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="rounded-[24px] bg-[#0f2c5c] text-white p-6 border-2 border-[#0a1e40] shadow-soft">
                <div className="text-[11px] tracking-[0.2em] opacity-70 uppercase">Motto del Gruppo</div>
                <div className="cond mt-2 text-[28px] leading-none font-bold">{settings?.value.motto || MOTTO_DEFAULT}</div>
                <div className="mt-4 text-sm opacity-90">Gruppo: <b>{groupCode}</b> — Tutti i volontari devono usare lo stesso codice gruppo per vedere gli stessi dati. Modificabile da Coordinatore.</div>
                <div className="mt-4 rounded-xl bg-white text-[#0f2c5c] p-3 text-[12px] leading-relaxed border-2 border-[#ffcc00] font-medium">
                  <b>FIX TASTIERA PIN per telefono:</b><br/>
                  • Campo PIN ora <b>bianco puro #ffffff</b> con testo <b>nero #000</b> e bordo <b>giallo 3px</b>.<br/>
                  • Tastierino custom giallo #ffcc00 con testo blu #0f2c5c, 60px altezza, ombra, visibile al sole.<br/>
                  • Forzato color-scheme light, -webkit-text-fill-color black, caret black.<br/>
                  • Non usa più tastiera sistema: si apre solo keypad in-app su tap.
                </div>
              </div>

              <div className="rounded-[24px] bg-white border-[2px] border-[#ffcc00] p-5 shadow-soft">
                <div className="cond font-bold text-[16px] text-[#0f2c5c]">Stato Sistema</div>
                <div className="mt-3 space-y-2 text-[13px] text-black">
                  <div className="flex justify-between"><span>Volontari</span><b>{volunteers.length}</b></div>
                  <div className="flex justify-between"><span>Eventi oggi</span><b>{filteredEvents.filter(e=> new Date(e.value.ts).toDateString()===new Date().toDateString()).length}</b></div>
                  <div className="flex justify-between"><span>Messaggi chat</span><b>{filteredChats.length}</b></div>
                  <div className="flex justify-between"><span>Gruppo attivo</span><b className="text-[#0f2c5c]">{groupCode}</b></div>
                  <div className="flex justify-between"><span>Sede</span><span className="font-mono text-[11px]">{SEDE.lat}, {SEDE.lng}</span></div>
                </div>
              </div>

              <div className="rounded-[20px] border-[2px] border-dashed border-[#ffcc00] bg-white p-4 text-[12px] text-black">
                <b className="text-[#0f2c5c]">Istruzioni Sync (per GitHub Pages)</b><br/>
                1. Pubblica questo file come <code>index.html</code>.<br/>
                2. Tutti aprono lo stesso link, inseriscono <b>stesso Codice Gruppo</b>.<br/>
                3. Il coordinatore può cambiare gruppo in ⚙ Impostazioni.<br/>
                4. I dati sono condivisi automaticamente (polling 15s). Nessun localStorage isolato.<br/>
                5. Per sync ultra-real-time, incolla Firebase config in impostazioni (opzionale).
              </div>
            </div>
          </div>
        ) : (
          <>
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="h-11 w-11 rounded-full bg-[#ffcc00] grid place-items-center font-black text-[#0f2c5c] border-2 border-[#0f2c5c]">{currentUser.value.name.slice(0,2).toUpperCase()}</div>
                <div>
                  <div className="font-bold leading-none">{currentUser.value.name}</div>
                  <div className="text-[11px] uppercase tracking-wide text-[var(--text-muted)]">{currentUser.value.role} • {groupCode}</div>
                </div>
              </div>
              <div className="flex gap-2">
                <button onClick={()=>{setCurrentUser(null); setPinInput(''); setShowPinPad(false);}} className="rounded-full border border-[var(--line)] bg-white px-4 py-2 text-[12px] font-bold uppercase text-black">Esci</button>
                <button onClick={reload} className="rounded-full bg-[var(--surface-2)] border border-[var(--line)] px-4 py-2 text-[12px] font-bold uppercase">↻ Sync ora</button>
              </div>
            </div>

            {showSettings && (
              <div className="mt-4 rounded-[20px] bg-white border-2 border-[#ffcc00] shadow-soft p-5">
                <div className="flex items-center justify-between">
                  <h3 className="cond text-[20px] font-bold text-[#0f2c5c]">⚙ Impostazioni Sincronizzazione</h3>
                  <button onClick={()=>setShowSettings(false)} className="text-[12px] underline">Chiudi</button>
                </div>
                {(currentUser.value.role==='coordinatore' || currentUser.value.role==='servizio') ? (
                  <div className="mt-4 grid md:grid-cols-2 gap-5">
                    <div className="space-y-3">
                      <label className="text-[11px] font-bold uppercase">Codice Gruppo (condiviso tra tutti)</label>
                      <input value={groupInput} onChange={e=>setGroupInput(e.target.value)} className="w-full rounded-xl border-2 border-[#ffcc00] bg-white px-4 py-3 font-bold tracking-wide text-black"/>
                      <p className="text-[11px] text-[var(--text-muted)]">Tutti i volontari devono inserire lo stesso codice. Cambialo qui e salva: filtra automaticamente i dati.</p>
                      <div className="rounded-xl bg-amber-50 border border-amber-200 p-3 text-[11px] text-amber-900">
                        <b>Come funziona il sync reale su GitHub Pages:</b><br/>
                        • Backend API <code>actions</code> condiviso (records.list/create).<br/>
                        • Polling ogni 15s + BroadcastChannel per schede stesso browser.<br/>
                        • Nessun localStorage isolato: se un volontario timbra, tutti vedono subito (al prossimo poll).<br/>
                        • Alternativa esterna: usa <code>{NPOINT_ENDPOINT}</code> come JSON bin pubblico per gruppo — {NPOINT_DOC}.
                      </div>
                    </div>
                    <div className="space-y-3">
                      <label className="text-[11px] font-bold uppercase">Firebase (opzionale - per real-time Firestore)</label>
                      <input placeholder="apiKey" value={fbApi} onChange={e=>setFbApi(e.target.value)} className="w-full rounded-xl border border-[var(--line)] px-4 py-2 text-[12px] bg-white text-black"/>
                      <input placeholder="projectId" value={fbProject} onChange={e=>setFbProject(e.target.value)} className="w-full rounded-xl border border-[var(--line)] px-4 py-2 text-[12px] bg-white text-black"/>
                      <div className="text-[11px] text-[var(--text-muted)]">Se compilato, l'app mostra "Firestore pronto" e puoi collegare SDK. Se vuoto, usa backend built-in che funziona già su Pages.</div>
                      <button onClick={saveSettings} className="w-full rounded-xl bg-[#0f2c5c] text-white py-3 font-bold uppercase text-[13px]">Salva e attiva sync</button>
                      <div className="rounded-xl bg-[var(--surface-2)] p-3 border border-[var(--line)] text-[11px] text-black">
                        Test: distanza sede {distance ? `${Math.round(distance)}m` : '...'} — {inRange ? '✅ In sede' : '❌ Fuori sede'}<br/>
                        GPS acc: {geo?.acc ? `${Math.round(geo.acc)}m` : '-'} {geoErr && `err ${geoErr}`}
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="mt-3 text-[13px]">Solo Coordinatore/Servizio può modificare sincronizzazione. Il tuo gruppo: <b>{groupCode}</b></div>
                )}

                {(currentUser.value.role==='coordinatore' || currentUser.value.role==='servizio') && (
                  <div className="mt-6 border-t border-[var(--line)] pt-5">
                    <div className="cond font-bold text-[18px]">Gestione Volontari — Modifica / Aggiungi</div>
                    <div className="mt-3 grid md:grid-cols-[1fr_1fr_140px_100px_auto] gap-2 items-end">
                      <input placeholder="Nome" value={editingVol ? editingVol.value.name : newVol.name} onChange={e=> editingVol ? setEditingVol({...editingVol, value:{...editingVol.value, name:e.target.value}}) : setNewVol({...newVol, name:e.target.value})} className="rounded-xl border border-[var(--line)] bg-white px-3 py-2.5 text-sm text-black"/>
                      <input placeholder="PIN" value={editingVol ? editingVol.value.pin : newVol.pin} onChange={e=> editingVol ? setEditingVol({...editingVol, value:{...editingVol.value, pin:e.target.value}}) : setNewVol({...newVol, pin:e.target.value})} className="rounded-xl border border-[var(--line)] bg-white px-3 py-2.5 text-sm text-black"/>
                      <select value={editingVol ? editingVol.value.role : newVol.role} onChange={e=> editingVol ? setEditingVol({...editingVol, value:{...editingVol.value, role:e.target.value as Role}}) : setNewVol({...newVol, role:e.target.value as Role})} className="rounded-xl border border-[var(--line)] bg-white px-3 py-2.5 text-sm text-black">
                        <option value="volontario">volontario</option><option value="coordinatore">coordinatore</option><option value="servizio">servizio</option>
                      </select>
                      <label className="flex items-center gap-1 text-[12px]"><input type="checkbox" checked={editingVol ? editingVol.value.active : newVol.active} onChange={e=> editingVol ? setEditingVol({...editingVol, value:{...editingVol.value, active:e.target.checked}}) : setNewVol({...newVol, active:e.target.checked})}/> attivo</label>
                      <div className="flex gap-2">
                        <button onClick={upsertVolunteer} className="rounded-xl bg-[#0f2c5c] text-white px-4 py-2.5 text-[12px] font-bold uppercase">{editingVol?'Salva':'Aggiungi'}</button>
                        {editingVol && <button onClick={()=>setEditingVol(null)} className="rounded-xl border px-3 py-2.5 text-[12px] bg-white text-black">Annulla</button>}
                      </div>
                    </div>
                    <div className="mt-4 grid md:grid-cols-2 gap-2">
                      {volunteers.map(v=>(
                        <div key={v.id} className="flex items-center justify-between rounded-xl border border-[var(--line)] bg-[var(--surface-2)] px-3 py-2">
                          <div className="text-[13px]"><b>{v.value.name}</b> <span className="text-[11px] opacity-70">({v.value.role}) {v.value.active?'':'— disattivo'}</span></div>
                          <div className="flex gap-1">
                            <button onClick={()=>setEditingVol(v)} className="text-[11px] rounded-full bg-white border px-2 py-1 text-black">Modifica</button>
                            <button onClick={()=>deleteVolunteer(v.id)} className="text-[11px] rounded-full bg-red-50 border border-red-200 text-red-700 px-2 py-1">Elimina</button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {tab==='home' && (
              <div className="mt-5 grid gap-4">
                <div className="grid md:grid-cols-3 gap-4">
                  <button disabled={busy} onClick={()=>doEvent('timbratura')} className={`btn-giant rounded-[22px] border-2 font-bold cond shadow-soft text-left p-5 flex flex-col justify-between ${inRange?'bg-emerald-500 border-emerald-600 text-white':'bg-white border-[var(--line)] text-black'}`}>
                    <div className="text-[13px] uppercase tracking-wide">📍 Timbratura</div>
                    <div className="text-[28px] leading-none">{inRange?'TIMBRA ENTRATA':'FUORI SEDE'}</div>
                    <div className="text-[12px] font-normal normal-case opacity-80">{distance!==null?`${Math.round(distance)}m da sede — raggio ${RAGGIO}m`:'In attesa GPS...'}</div>
                  </button>

                  <button disabled={busy} onClick={()=>doEvent('fine_servizio')} className="btn-giant rounded-[22px] bg-[#0f2c5c] text-white border-2 border-[#0a1e40] shadow-soft text-left p-5 flex flex-col justify-between">
                    <div className="text-[13px] uppercase tracking-wide opacity-80">🏁 Servizio</div>
                    <div className="text-[28px] leading-none">FINE SERVIZIO</div>
                    <div className="text-[12px] font-normal normal-case opacity-80">Chiude turno e registra orario</div>
                  </button>

                  <button disabled={busy || !canEmergency} onClick={()=>doEvent('emergenza','Emergenza da app')} className={`btn-giant rounded-[22px] border-2 shadow-soft text-left p-5 flex flex-col justify-between ${canEmergency?'bg-[#E11D48] border-red-700 text-white':'bg-zinc-200 border-zinc-300 text-zinc-500'}`}>
                    <div className="text-[13px] uppercase tracking-wide">🚨 Emergenza</div>
                    <div className="text-[28px] leading-none">{canEmergency?'SEGNALA EMERGENZA':'ATTESA 30 MIN'}</div>
                    <div className="text-[12px] font-normal normal-case opacity-80">{lastEmergency?`Ultima ${fmtTime(lastEmergency)}`:'Nessuna recente'}</div>
                  </button>
                </div>

                <div className="grid md:grid-cols-[1.2fr_0.8fr] gap-4">
                  <div className="rounded-[20px] bg-white border-2 border-[#ffcc00] p-5 shadow-soft">
                    <div className="flex items-center justify-between">
                      <h3 className="cond font-bold text-[18px] text-[#0f2c5c]">Richieste Ferie / Reperibilità</h3>
                      <span className="text-[11px] bg-[#ffcc00] border-2 border-[#0f2c5c] rounded-full px-2 py-1 uppercase font-black text-[#0f2c5c]">Sincronizzato</span>
                    </div>
                    <div className="mt-4 grid grid-cols-[110px_1fr_1fr_auto] gap-2">
                      <select value={ferieTipo} onChange={e=>setFerieTipo(e.target.value as any)} className="rounded-xl border-2 border-[#ffcc00] bg-white px-3 py-2.5 text-[13px] text-black"><option value="ferie">Ferie</option><option value="reperibilita">Reperibilità</option></select>
                      <input type="date" value={ferieFrom} onChange={e=>setFerieFrom(e.target.value)} className="rounded-xl border-2 border-[#ffcc00] bg-white px-3 py-2.5 text-[13px] text-black"/>
                      <input type="date" value={ferieTo} onChange={e=>setFerieTo(e.target.value)} className="rounded-xl border-2 border-[#ffcc00] bg-white px-3 py-2.5 text-[13px] text-black"/>
                      <button onClick={sendRequest} className="rounded-xl bg-[#ffcc00] text-[#0f2c5c] border-2 border-[#0f2c5c] px-4 py-2.5 text-[12px] font-black uppercase">Invia</button>
                    </div>

                    <div className="mt-4 space-y-2 max-h-[220px] overflow-auto pr-1">
                      {filteredRequests.slice(0,12).map(r=>(
                        <div key={r.id} className="flex items-center justify-between rounded-xl border border-[var(--line)] bg-[var(--surface-2)] px-3 py-2 text-[12px]">
                          <div><b>{r.value.volunteerName}</b> {r.value.type} {r.value.from}→{r.value.to} <span className={`ml-2 rounded-full px-2 py-0.5 text-[10px] uppercase font-bold ${r.value.status==='approvata'?'bg-emerald-100 text-emerald-700': r.value.status==='rifiutata'?'bg-red-100 text-red-700':'bg-amber-100 text-amber-700'}`}>{r.value.status}</span></div>
                          {(currentUser.value.role!=='volontario') && r.value.status==='in_attesa' && (
                            <div className="flex gap-1">
                              <button onClick={()=>approveRequest(r.id,'approvata')} className="rounded-full bg-emerald-600 text-white px-2 py-1 text-[10px]">OK</button>
                              <button onClick={()=>approveRequest(r.id,'rifiutata')} className="rounded-full bg-zinc-800 text-white px-2 py-1 text-[10px]">NO</button>
                            </div>
                          )}
                        </div>
                      ))}
                      {filteredRequests.length===0 && <div className="text-[12px] text-[var(--text-muted)]">Nessuna richiesta per {groupCode}</div>}
                    </div>
                  </div>

                  <div className="rounded-[20px] bg-white border-2 border-[#0f2c5c] p-5 shadow-soft">
                    <h3 className="cond font-bold text-[18px] text-[#0f2c5c]">Ultimi Eventi — {groupCode}</h3>
                    <div className="mt-3 space-y-2 max-h-[260px] overflow-auto">
                      {filteredEvents.slice(0,20).map(ev=>(
                        <div key={ev.id} className="flex gap-2 rounded-xl border border-[var(--line)] px-3 py-2 text-[12px] bg-[var(--surface-2)] text-black">
                          <span className={`mt-1 h-2 w-2 rounded-full flex-shrink-0 ${ev.value.type==='emergenza'?'bg-red-500': ev.value.type==='timbratura'?'bg-emerald-500':'bg-blue-500'}`}/>
                          <div><b>{ev.value.volunteerName}</b> {ev.value.type.replace('_',' ')} — {fmtTime(ev.value.ts)} {ev.value.distance?`(${Math.round(ev.value.distance)}m)`:''}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {tab==='timbra' && (
              <div className="mt-5 rounded-[24px] bg-white border-2 border-[#ffcc00] p-6 shadow-soft">
                <h2 className="cond text-[28px] font-bold text-[#0f2c5c]">Timbratura GPS — Verifica Sede</h2>
                <div className="mt-4 grid md:grid-cols-2 gap-4">
                  <div className="rounded-xl bg-[var(--surface-2)] border-2 border-[#0f2c5c] p-4">
                    <div className="text-[12px] uppercase font-bold tracking-wide">Posizione attuale</div>
                    <div className="mt-2 font-mono text-[13px] text-black">{geo? `${geo.lat.toFixed(6)}, ${geo.lng.toFixed(6)} ±${Math.round(geo.acc)}m` : 'In attesa...'}</div>
                    <div className="mt-3 text-[13px] text-black">Distanza da sede: <b>{distance!==null? `${Math.round(distance)}m` : '-'}</b> (limite {RAGGIO}m)</div>
                    <div className={`mt-3 rounded-xl px-4 py-3 font-bold text-[14px] border-2 ${inRange?'bg-emerald-100 text-emerald-800 border-emerald-600':'bg-red-50 text-red-700 border-red-300'}`}>{inRange? '✅ Sei in sede, puoi timbrare':'❌ Fuori sede - avvicinati'}</div>
                    <button disabled={!inRange||busy} onClick={()=>doEvent('timbratura')} className="mt-4 w-full btn-giant rounded-[16px] bg-emerald-600 text-white font-bold cond text-[22px] disabled:opacity-40 border-2 border-emerald-800">TIMBRA ORA</button>
                    {geoErr && <div className="mt-2 text-[11px] text-red-600">{geoErr}</div>}
                  </div>
                  <div className="rounded-xl border-2 border-[#ffcc00] p-4 text-[12px] leading-relaxed bg-white text-black">
                    <b>Come funziona:</b><br/>
                    • GPS del telefono confrontato con {SEDE.lat}, {SEDE.lng}<br/>
                    • Formula Haversine, tolleranza {RAGGIO}m<br/>
                    • Timbratura salvata su backend condiviso → visibile a Coordinatore e Servizio su altri dispositivi.<br/>
                    • Se fuori sede, il bottone resta disattivo per sicurezza.<br/>
                    <br/>
                    <b>Fix GitHub Pages:</b> prima il dato restava in localStorage locale. Ora viene scritto in <code>records.create('events')</code> e letto da tutti i dispositivi con stesso <b>{groupCode}</b>.
                  </div>
                </div>
              </div>
            )}

            {tab==='emergenza' && (
              <div className="mt-5 space-y-4">
                <div className="rounded-[24px] bg-[#E11D48] text-white p-6 border-2 border-red-800">
                  <h2 className="cond text-[32px] font-bold leading-none">Segnalazione Emergenza</h2>
                  <p className="mt-2 text-[13px] opacity-90">Puoi segnalare ogni 30 minuti. La segnalazione viene sincronizzata in tempo reale con Coordinatore e Servizio.</p>
                  <button disabled={!canEmergency||busy} onClick={()=>doEvent('emergenza','Emergenza urgente')} className="mt-5 w-full btn-giant rounded-[16px] bg-white text-[#E11D48] font-bold cond text-[26px] disabled:opacity-50 border-2 border-white">🚨 INVIA EMERGENZA ORA</button>
                  {!canEmergency && lastEmergency && <div className="mt-3 text-[12px]">Ultima: {fmtTime(lastEmergency)} — prossimo invio tra {Math.ceil((EMERGENCY_COOLDOWN - (Date.now()-lastEmergency))/60000)} min</div>}
                </div>
                <div className="rounded-[20px] bg-white border-2 border-red-200 p-5">
                  <h3 className="cond font-bold text-[#0f2c5c]">Storico emergenze — {groupCode}</h3>
                  <div className="mt-3 space-y-2">
                    {filteredEvents.filter(e=>e.value.type==='emergenza').slice(0,15).map(ev=>(
                      <div key={ev.id} className="rounded-xl border border-red-200 bg-red-50 px-3 py-2 text-[12px] text-red-900 flex justify-between"><span><b>{ev.value.volunteerName}</b> — {fmtTime(ev.value.ts)}</span><span className="font-mono">{ev.value.lat?.toFixed(4)},{ev.value.lng?.toFixed(4)}</span></div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {tab==='chat' && (
              <div className="mt-5 rounded-[24px] bg-white border-2 border-[#0f2c5c] shadow-soft flex flex-col h-[66vh]">
                <div className="p-4 border-b border-[var(--line)] flex justify-between items-center bg-[#ffcc00]">
                  <h3 className="cond font-bold text-[18px] text-[#0f2c5c]">Chat di Squadra — {groupCode} — Sync reale</h3>
                  <span className="text-[11px] px-2 py-1 rounded-full bg-[#0f2c5c] border border-white text-white font-bold">● LIVE</span>
                </div>
                <div className="flex-1 overflow-auto p-4 space-y-3 bg-[#f6f8fc]">
                  {filteredChats.map(c=>(
                    <div key={c.id} className={`max-w-[78%] rounded-[16px] px-4 py-2 text-[13px] ${c.value.volunteerId===currentUser?.id ? 'ml-auto bg-[#0f2c5c] text-white border-2 border-[#0a1e40]' : 'bg-white border-2 border-[#ffcc00] text-black'}`}>
                      <div className="text-[10px] uppercase opacity-70 font-bold">{c.value.volunteerName} • {fmtTime(c.value.ts)}</div>
                      <div className="mt-1">{c.value.message}</div>
                    </div>
                  ))}
                  {filteredChats.length===0 && <div className="text-[12px] text-black/60">Nessun messaggio per questo gruppo. Scrivi il primo!</div>}
                </div>
                <div className="p-3 border-t-2 border-[#ffcc00] flex gap-2 bg-white">
                  <input value={chatMsg} onChange={e=>setChatMsg(e.target.value)} onKeyDown={e=> e.key==='Enter' && sendChat()} placeholder="Messaggio a tutta la squadra..." className="flex-1 rounded-full border-2 border-[#ffcc00] bg-white px-4 py-3 text-[14px] text-black"/>
                  <button onClick={sendChat} className="rounded-full bg-[#0f2c5c] text-white px-6 py-3 font-bold text-[13px] uppercase border-2 border-[#0a1e40]">Invia</button>
                </div>
              </div>
            )}

            {tab==='schede' && (
              <div className="mt-5 space-y-4">
                <div className="flex flex-wrap items-center gap-3">
                  <h2 className="cond text-[26px] font-bold text-[#0f2c5c]">Schede Mese per Mese — Presenze</h2>
                  <div className="flex items-center gap-2 rounded-full bg-white border-2 border-[#ffcc00] px-2 py-1">
                    <button onClick={()=>{ if(month===0){setMonth(11); setYear(y=>y-1);} else setMonth(m=>m-1); }} className="h-8 w-8 grid place-items-center rounded-full bg-[#ffcc00] text-[#0f2c5c] font-bold border">‹</button>
                    <span className="px-3 text-[13px] font-bold uppercase text-black">{new Date(year,month).toLocaleDateString('it-IT',{month:'long',year:'numeric'})}</span>
                    <button onClick={()=>{ if(month===11){setMonth(0); setYear(y=>y+1);} else setMonth(m=>m+1); }} className="h-8 w-8 grid place-items-center rounded-full bg-[#ffcc00] text-[#0f2c5c] font-bold border">›</button>
                  </div>
                </div>

                <div className="grid md:grid-cols-3 gap-3">
                  {volunteers.filter(v=>v.value.active).map(vol=>{
                    const evs = monthEvents.filter(e=> e.value.volunteerId===vol.id);
                    const timb = evs.filter(e=>e.value.type==='timbratura').length;
                    const fines = evs.filter(e=>e.value.type==='fine_servizio').length;
                    const emerg = evs.filter(e=>e.value.type==='emergenza').length;
                    return (
                      <div key={vol.id} className="rounded-[18px] bg-white border-2 border-[#0f2c5c] p-4 shadow-soft">
                        <div className="flex justify-between items-start">
                          <div><b className="text-[14px] text-black">{vol.value.name}</b><div className="text-[11px] uppercase text-black/60">{vol.value.role}</div></div>
                          <div className="text-[11px] rounded-full bg-[#ffcc00] border-2 border-[#0f2c5c] px-2 py-1 font-black text-[#0f2c5c]">{timb} timb.</div>
                        </div>
                        <div className="mt-3 grid grid-cols-3 gap-2 text-[11px] text-center">
                          <div className="rounded-xl bg-emerald-50 border-2 border-emerald-600 py-2 text-black"><b className="block text-[16px]">{timb}</b>Entrate</div>
                          <div className="rounded-xl bg-blue-50 border-2 border-blue-600 py-2 text-black"><b className="block text-[16px]">{fines}</b>Uscite</div>
                          <div className="rounded-xl bg-red-50 border-2 border-red-600 py-2 text-black"><b className="block text-[16px]">{emerg}</b>Emerg.</div>
                        </div>
                        <div className="mt-3 space-y-1 max-h-[110px] overflow-auto">
                          {evs.slice(0,10).map(e=>(
                            <div key={e.id} className="text-[11px] flex justify-between border-b border-dashed border-[var(--line)] py-1 text-black"><span>{fmtDate(e.value.ts)} {e.value.type}</span><span className="font-mono">{new Date(e.value.ts).toLocaleTimeString('it-IT',{hour:'2-digit',minute:'2-digit'})}</span></div>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>

                <div className="rounded-[16px] bg-[#0f2c5c] text-white p-4 text-[12px] border-2 border-[#0a1e40]">Tutti i dati filtrati per gruppo <b>{groupCode}</b>. Esportazione mese: {monthEvents.length} eventi totali. Sincronizzazione attiva ogni 15s + BroadcastChannel.</div>
              </div>
            )}
          </>
        )}
      </main>

      {currentUser && (
        <nav className="fixed bottom-0 inset-x-0 z-30 border-t-2 border-[#ffcc00] bg-white/95 glass">
          <div className="mx-auto max-w-[1080px] grid grid-cols-5 gap-1 px-2 py-2">
            {[
              {k:'home', l:'Home', i:'🏠'},
              {k:'timbra', l:'Timbra', i:'📍'},
              {k:'emergenza', l:'SOS', i:'🚨'},
              {k:'chat', l:'Chat', i:'💬'},
              {k:'schede', l:'Schede', i:'🗓️'},
            ].map(item=>(
              <button key={item.k} onClick={()=>setTab(item.k as any)} className={`flex flex-col items-center justify-center rounded-[14px] py-2.5 border-2 ${tab===item.k ? 'bg-[#0f2c5c] text-white border-[#0a1e40] shadow-soft' : 'text-black bg-white border-[#ffcc00]'}`}>
                <span className="text-[18px] leading-none">{item.i}</span>
                <span className="mt-1 text-[10px] font-bold uppercase tracking-wide">{item.l}</span>
              </button>
            ))}
          </div>
          <div className="h-[env(safe-area-inset-bottom)] bg-white" />
        </nav>
      )}

      <div className="pointer-events-none fixed bottom-[96px] right-3 hidden md:block rounded-full bg-[#ffcc00] px-3 py-1 text-[11px] font-black uppercase shadow-soft border-2 border-[#0f2c5c] text-[#0f2c5c]">PWA pronta • Tastiera Fix • Sync {syncState}</div>
    </div>
  );
}
